"""Explicit many-bank-rows to one ledger movement, with previewed corrections."""
import json
from backend.ledger import Ledger, ValidationError
from backend.bank_compare import cents
from backend.bank_review import fingerprint


def state_stamp(bank):
    edits=[]
    if bank.db.execute("SELECT 1 FROM sqlite_master WHERE name='history_edits'").fetchone():
        edits=[list(r) for r in bank.db.execute('SELECT * FROM history_edits ORDER BY source_row,revision')]
    return fingerprint({'ledger':bank.ledger.snapshot(),'edits':edits,'transactions':bank.get('transactions',{}),
                        'mapping':bank.get('mapping',{}),'links':bank.get('links',{})})


def group(bank, data, commit=False):
    if not bank.writable:raise ValidationError('This bank connection is preview-only.')
    ids=data.get('transaction_ids')
    if not isinstance(ids,list) or not 1<=len(ids)<=100 or any(not isinstance(i,str) for i in ids) or len(set(ids))!=len(ids):
        raise ValidationError('Select 1–100 distinct bank transactions.')
    transactions=bank.get('transactions',{});mapping=bank.get('mapping',{});links=bank.get('links',{})
    chosen=[transactions.get(i) for i in ids]
    if any(t is None for t in chosen):raise ValidationError('A bank row disappeared. Reload and select again.')
    if any(not bank.in_scope(t) for t in chosen):raise ValidationError('Bank entry is outside this ledger’s import period.')
    if any(i in links for i in ids):raise ValidationError('A selected row is already linked.')
    targets={mapping.get(t['account_id']) for t in chosen}
    if len(targets)!=1 or None in targets:raise ValidationError('Select transactions mapped to the same ledger account.')
    account=targets.pop();accounts=bank.ledger.accounts()
    if account not in accounts:raise ValidationError('Mapped account no longer exists.')
    amounts=[cents(t.get('amount')) for t in chosen]
    if any(a is None for a in amounts) or any(t.get('iso_currency_code')!='USD' for t in chosen):raise ValidationError('Choose USD transactions with exact amounts.')
    if not all(a>0 for a in amounts) and not all(a<0 for a in amounts):raise ValidationError('Choose amounts with the same direction, not unrelated incoming and outgoing movements.')
    total=sum(amounts);delta=total if accounts[account]['kind']=='card' else -total
    before=bank.ledger.snapshot();entry=next((e for e in before['transactions'] if e['id']==data.get('event_id')),None)
    if not entry or entry.get('status')!='posted' or not entry['effects']['accounts'].get(account):raise ValidationError('Choose a posted manual entry affecting this account.')
    old_delta=entry['effects']['accounts'][account]
    if (old_delta>0)!=(delta>0):raise ValidationError('The entry moves money in the opposite direction.')
    if any(v.get('event_id')==entry['id'] and v.get('account')==account for v in links.values()):raise ValidationError('This manual movement already has linked bank rows.')
    stamp=state_stamp(bank)
    token=fingerprint({'state':stamp,'ids':sorted(ids),'entry':entry['id']})
    if commit and data.get('preview_token')!=token:raise ValidationError('Data changed since preview. Preview again before approving.')
    clone=Ledger(':memory:');bank.db.backup(clone.db)
    history_changes=[];updated=None
    try:
        if delta!=old_delta:
            if entry['kind']=='historical':
                from backend.history import history_snapshot,migrate_confirmed_inputs
                archive=history_snapshot(clone)
                row=next(r for r in archive['transactions'] if r['source_row']==entry['source_row'])
                inputs=list(row['values'][:6]);amount=abs(total)/100
                original_kind=entry.get('original_kind')
                if original_kind=='repayment_received':inputs[2]=-amount
                elif original_kind in ('purchase','card_payment','deposit_purpose_unconfirmed','transfer'):
                    if isinstance(inputs[2],(int,float)) and inputs[2]>amount:raise ValidationError('The corrected purchase is smaller than its shared amount. Correct the split in Raw mode first.')
                    inputs[1]=amount
                else:raise ValidationError('This historical entry needs a Raw mode correction first.')
                history_changes=[(row,inputs)]
                if original_kind=='transfer':
                    dest=next((r for r in archive['transactions'] if r['source_row']>row['source_row']),None)
                    if not dest or dest['category']!='Deposit' or dest['amount_cents']!=row['amount_cents']:raise ValidationError('Cannot identify this transfer’s other source row. Correct it in Raw mode.')
                    values=list(dest['values'][:6]);values[1]=amount;history_changes.append((dest,values))
                for r,values in history_changes:
                    clone.db.execute('INSERT INTO history_edits(source_sha256,source_row,revision,inputs) VALUES(?,?,?,?)',(archive['sha256'],r['source_row'],r['edit_revision']+1,json.dumps(values)))
                clone.db.commit();migrate_confirmed_inputs(clone,rebuild=True)
            else:
                record=clone.db.execute('SELECT payload FROM events WHERE id=?',(entry['id'],)).fetchone()
                payload=json.loads(record[0]);payload['amount_cents']=abs(total)
                if payload['kind']=='purchase':
                    payload['personal_cents']=abs(total)-sum(s['amount_cents'] for s in payload.get('shares',[]))
                    if payload['personal_cents']<0:raise ValidationError('Correct the split first; bank total is smaller than the other people’s shares.')
                if payload['kind']=='refund':
                    payload['personal_cents']=abs(total)
                clone.save_event(payload,entry['id'],entry['revision'])
                updated=dict(clone.db.execute('SELECT * FROM events WHERE id=?',(entry['id'],)).fetchone())
        after=clone.snapshot()
        corrected=next((e for e in after['transactions'] if e['id']==entry['id']),None)
        if not corrected or corrected['effects']['accounts'].get(account)!=delta:raise ValidationError('Correction did not produce the selected bank amount.')
        # A correction can affect both sides of a CP/transfer; don't contradict an
        # already reconciled opposite leg without requiring the user to review it.
        if delta!=old_delta and any(v.get('event_id')==entry['id'] for v in links.values()):
            raise ValidationError('Another side of this entry is already linked. Review that link before changing the amount.')
        display_sign=-1 if accounts[account]['kind']=='card' else 1
        changes=[]
        for kind in ('accounts','people'):
            old={a['id']:a for a in before[kind]}
            for a in after[kind]:
                previous=old[a['id']]['posted_balance_cents'];new=a['posted_balance_cents']
                if previous!=new:
                    sign=-1 if kind=='accounts' and a['kind']=='card' else 1
                    changes.append({'name':a['name'],'before':None if previous is None else sign*previous,'after':None if new is None else sign*new})
        result={'preview_token':token,'account':account,'bank_cents':delta*display_sign,'manual_cents':old_delta*display_sign,
                'difference_cents':(delta-old_delta)*display_sign,'changes':changes,'description':entry['description'],
                'spending_change_cents':after['personal_spending_cents']-before['personal_spending_cents'],
                'checkpoint_preserved':bool(next((a.get('confirmed_checkpoint') for a in before['accounts'] if a['id']==account),None))}
        if not commit:return result
        bank.db.execute('BEGIN IMMEDIATE')
        if state_stamp(bank)!=stamp:
            bank.db.rollback();raise ValidationError('Ledger changed during preview. Try again.')
        with bank.db:
            if updated:
                bank.db.execute('UPDATE events SET payload=?,revision=? WHERE id=?',(updated['payload'],updated['revision'],entry['id']))
                revision=clone.db.execute('SELECT * FROM revisions WHERE event_id=? AND revision=?',(entry['id'],updated['revision'])).fetchone()
                bank.db.execute('INSERT INTO revisions VALUES(?,?,?,?)',tuple(revision))
            if history_changes:
                for r,values in history_changes:
                    bank.db.execute('INSERT INTO history_edits(source_sha256,source_row,revision,inputs) VALUES(?,?,?,?)',(archive['sha256'],r['source_row'],r['edit_revision']+1,json.dumps(values)))
                bank.db.execute('DELETE FROM imported_events')
                for r in clone.db.execute('SELECT seq,id,entered_at,payload FROM imported_events'):
                    bank.db.execute('INSERT INTO imported_events(seq,id,entered_at,payload) VALUES(?,?,?,?)',tuple(r))
            for tid,t in zip(ids,chosen):links[tid]={'event_id':entry['id'],'account':account,'fingerprint':fingerprint(t),'group_ids':ids}
            bank.put('links',links)
        return bank.status()
    finally:clone.close()
