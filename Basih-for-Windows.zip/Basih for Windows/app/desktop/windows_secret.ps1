param([Parameter(Mandatory=$true)][string]$Action,[Parameter(Mandatory=$true)][string]$Account)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
$root = Join-Path $env:LOCALAPPDATA 'Basih\Secrets'
$sha = [System.Security.Cryptography.SHA256]::Create()
$name = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Account)))).Replace('-','').ToLower()
$path = Join-Path $root ($name + '.bin')
try {
  if ($Action -eq 'set') {
    [IO.Directory]::CreateDirectory($root) | Out-Null
    $plain = [Text.Encoding]::UTF8.GetBytes([Console]::In.ReadToEnd())
    $protected = [Security.Cryptography.ProtectedData]::Protect($plain,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
    [IO.File]::WriteAllBytes($path,$protected)
  } elseif ($Action -eq 'get') {
    if (!(Test-Path $path)) { exit 3 }
    $plain = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($path),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
    [Console]::Out.Write([Text.Encoding]::UTF8.GetString($plain))
  } elseif ($Action -eq 'delete') {
    if (Test-Path $path) { Remove-Item -LiteralPath $path -Force }
  } else { exit 2 }
} catch { exit 1 }
