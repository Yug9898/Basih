@echo off
cd /d "%~dp0"
if not exist "%~dp0app\desktop\windows_entry.py" (
  echo Please extract the entire ZIP first, then run Install Basih.cmd from the extracted folder.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo Basih setup failed. Copy the error above or send basih-install.log from this folder.
) else (
  echo Setup finished. Open the Basih shortcut on your Desktop.
)
pause
