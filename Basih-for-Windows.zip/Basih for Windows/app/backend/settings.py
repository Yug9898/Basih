"""Local profile, rate-limited reset PIN, and explicit database reset."""
import hashlib,hmac,json,secrets,time,os
from backend.ledger import ValidationError,DEFAULT_ACCOUNTS,CATEGORIES,required_text,cents

def get(ledger,key,default=None):
 r=ledger.db.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()
 return r[0] if r else default
def put(ledger,key,value):ledger.db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',(key,str(value)))
def status(ledger):
 return {'name':get(ledger,'profile_name'),'has_passcode':get(ledger,'reset_pin') is not None,'locked_until':float(get(ledger,'pin_locked_until',0)), 'launch_lock':get(ledger,'launch_lock','0')=='1','idle_minutes':int(get(ledger,'idle_minutes',0)), 'can_delete_cards':True,'theme':get(ledger,'theme','system'),'palette':get(ledger,'palette','blue')}

def set_lock(ledger,pin,enabled,idle_minutes):
 if not isinstance(enabled,bool) or type(idle_minutes) is not int or idle_minutes not in (0,1,5,15,30):
  raise ValidationError('Choose a valid lock setting.')
 verify(ledger,pin)
 with ledger.db:
  put(ledger,'launch_lock','1' if enabled else '0')
  put(ledger,'idle_minutes',idle_minutes if enabled else 0)
 return status(ledger)

def set_palette(ledger,palette):
 if palette not in ('blue','pink','orange','gold','ai'):raise ValidationError('Choose Blue, Pink, Developer Special, Gold or AI.')
 with ledger.db:put(ledger,'palette',palette)
 return {'palette':palette}

def set_theme(ledger,theme):
 if theme not in ('light','dark','system'):raise ValidationError('Choose Light, Dark or Device.')
 with ledger.db:put(ledger,'theme',theme)
 return {'theme':theme}

def delete_card(ledger,account_id):
 account=ledger.accounts().get(account_id)
 if not account or account['kind']!='card':raise ValidationError('Choose an existing card.')
 return delete_account(ledger,account_id)

def link_card(ledger,account_id,bank_id):
 accounts=ledger.accounts()
 if account_id not in accounts or accounts[account_id]['kind']!='card':raise ValidationError('Choose a credit card.')
 if bank_id is not None and (bank_id not in accounts or accounts[bank_id]['kind']!='bank'):raise ValidationError('Choose a bank.')
 with ledger.db:ledger.db.execute('UPDATE accounts SET default_payment_account=? WHERE id=?',(bank_id,account_id))
 return {'linked':account_id}

def delete_account(ledger,account_id):
 with ledger.db:
  ledger.db.execute('BEGIN IMMEDIATE')
  account=ledger.accounts().get(account_id)
  if not account:raise ValidationError('Choose an existing account.')
  for row in ledger.db.execute('SELECT payload FROM revisions'):
   event=json.loads(row[0])
   from backend.ledger import CARD_PAYMENTS
   payment=CARD_PAYMENTS.get(event.get('category'),())
   if event.get('payment_bank_id')==account_id or event.get('account_id')==account_id or event.get('destination_account_id')==account_id or event.get('payer',{}).get('id')==account_id or account_id in payment:
    raise ValidationError('This account has recorded entries and cannot be deleted.')
  from backend.history import has_history
  if has_history(ledger):
   if any(account_id in entry['effects']['accounts'] for entry in ledger.snapshot()['transactions']):
    raise ValidationError('This account has recorded entries and cannot be deleted.')
  linked=[a['name'] for a in ledger.accounts().values() if a['default_payment_account']==account_id]
  if linked:raise ValidationError('This bank is linked to '+', '.join(linked)+'. Remove the linked cards first.')
  ledger.db.execute('DELETE FROM accounts WHERE id=?',(account_id,))
  ledger.db.execute('DELETE FROM meta WHERE key=?',('bank_opening_basis:'+account_id,))
  for table in ('bank_stage','bank_stage_production'):
   if ledger.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():
    row=ledger.db.execute(f"SELECT value FROM {table} WHERE key='mapping'").fetchone()
    if row:
     mapping=json.loads(row[0]);mapping={source:target for source,target in mapping.items() if target!=account_id}
     ledger.db.execute(f"UPDATE {table} SET value=? WHERE key='mapping'",(json.dumps(mapping),))
  put(ledger,'deleted_account:'+account_id,'1')
 return {'deleted':account_id}

def merge_account(ledger,source_id,target_id):
 accounts=ledger.accounts()
 source,target=accounts.get(source_id),accounts.get(target_id)
 if not source or not target or source_id==target_id:raise ValidationError('Choose two different existing accounts.')
 if source['kind']!=target['kind']:raise ValidationError('Banks can merge only into banks, and cards only into cards.')
 from backend import backups
 safety=backups.create(ledger,'Before account merge')
 source_code,target_code=source.get('payment_code'),target.get('payment_code')
 def moved(payload):
  event=json.loads(payload)
  for key in ('account_id','payment_bank_id','destination_account_id'):
   if event.get(key)==source_id:event[key]=target_id
  payer=event.get('payer')
  if isinstance(payer,dict) and payer.get('type')=='account' and payer.get('id')==source_id:payer['id']=target_id
  if event.get('kind')=='card_payment' and source_code and event.get('category')==source_code:
   event['category']=target_code or 'Card payment'
  return json.dumps(event,sort_keys=True)
 with ledger.db:
  # The Plaid-derived duplicate is authoritative for the opening at the chosen
  # ledger start date. Its imported movements are then reassigned intact.
  if source['opening_cents'] is not None:
   ledger.db.execute('UPDATE accounts SET opening_cents=? WHERE id=?',(source['opening_cents'],target_id))
  ledger.db.execute('UPDATE accounts SET default_payment_account=? WHERE default_payment_account=?',(target_id,source_id))
  for row in ledger.db.execute('SELECT id,payload FROM events').fetchall():
   ledger.db.execute('UPDATE events SET payload=? WHERE id=?',(moved(row['payload']),row['id']))
  for row in ledger.db.execute('SELECT event_id,revision,payload FROM revisions').fetchall():
   ledger.db.execute('UPDATE revisions SET payload=? WHERE event_id=? AND revision=?',(moved(row['payload']),row['event_id'],row['revision']))
  for table in ('bank_stage','bank_stage_production'):
   if ledger.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():
    row=ledger.db.execute(f"SELECT value FROM {table} WHERE key='mapping'").fetchone()
    if row:
     mapping=json.loads(row[0]);mapping={key:(target_id if value==source_id else value) for key,value in mapping.items()}
     ledger.db.execute(f"UPDATE {table} SET value=? WHERE key='mapping'",(json.dumps(mapping),))
  basis=get(ledger,'bank_opening_basis:'+source_id)
  if basis is not None:put(ledger,'bank_opening_basis:'+target_id,basis)
  ledger.db.execute('DELETE FROM meta WHERE key IN (?,?)',('bank_opening_basis:'+source_id,'payment_code:'+source_id))
  ledger.db.execute('DELETE FROM accounts WHERE id=?',(source_id,))
  put(ledger,'deleted_account:'+source_id,'1')
 # Validate the migrated live ledger before reporting success. The automatic
 # safety backup remains available if older unusual data needs recovery.
 ledger.snapshot()
 return {'merged':source_id,'into':target_id,'safety_backup':str(safety)}

def delete_person(ledger,person_id):
 with ledger.db:
  ledger.db.execute('BEGIN IMMEDIATE')
  person=ledger.people().get(person_id)
  if not person:raise ValidationError('Person not found.')
  # Revisions are an audit log and retain the original payload after an entry
  # is deleted. Only current, active entries should prevent person deletion.
  if any(person_id in entry['effects']['people'] for entry in ledger.snapshot()['transactions']):
   raise ValidationError('This person has recorded entries and cannot be deleted.')
  ledger.db.execute('DELETE FROM person_notes WHERE person_id=?',(person_id,))
  ledger.db.execute('DELETE FROM people WHERE id=?',(person_id,))
 return {'deleted':person_id}

RESERVED_CATEGORIES={'Deposit','Transfer','Debited','Card payment','Opening balance'}
def _category_name(value):
 value=required_text(value,'Category',40)
 if value.upper().startswith('CP') and value[2:].isdigit() or value.casefold() in {name.casefold() for name in RESERVED_CATEGORIES}:
  raise ValidationError('That name is reserved for money movements.')
 return value
def add_category(ledger,name):
 name=_category_name(name)
 if any(existing.casefold()==name.casefold() for existing in ledger.spending_categories()):raise ValidationError('That category already exists.')
 if len(ledger.spending_categories())>=30:raise ValidationError('Basih supports up to 30 spending categories.')
 with ledger.db:
  position=ledger.db.execute('SELECT COALESCE(MAX(position),-1)+1 FROM categories').fetchone()[0]
  ledger.db.execute('INSERT INTO categories(name,position) VALUES(?,?)',(name,position))
 return {'categories':ledger.spending_categories()}
def delete_category(ledger,name):
 category=next((item for item in ledger.spending_categories() if item.casefold()==str(name).casefold()),None)
 if not category:raise ValidationError('Category not found.')
 if len(ledger.spending_categories())==1:raise ValidationError('Keep at least one spending category.')
 for table in ('events','imported_events'):
  if ledger.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():
   for row in ledger.db.execute(f'SELECT payload FROM {table}'):
    event=json.loads(row[0])
    if event.get('status')!='voided' and event.get('category')==category:raise ValidationError('This category has active entries. Move those entries to another category first.')
 with ledger.db:ledger.db.execute('DELETE FROM categories WHERE name=?',(category,))
 return {'categories':ledger.spending_categories()}
def valid_pin(pin):
 if not isinstance(pin,str) or len(pin)!=4 or not pin.isascii() or not pin.isdigit():raise ValidationError('Use a four-digit passcode.')
 return pin

def set_year_basis(ledger,basis):
 if basis not in ('tracking','fiscal'):raise ValidationError('Choose August 21 or April 1.')
 with ledger.db:put(ledger,'report_year_basis',basis)
 return {'year_basis':basis}
def verify(ledger,pin,*,stored_hash=None):
 valid_pin(pin)
 if float(get(ledger,'pin_locked_until',0))>time.time():raise ValidationError('Too many attempts. Try again in 30 seconds.')
 stored=stored_hash or get(ledger,'reset_pin')
 if not stored:raise ValidationError('Set a passcode first.')
 salt,expected=stored.split(':')
 actual=hashlib.pbkdf2_hmac('sha256',pin.encode(),bytes.fromhex(salt),180000).hex()
 if not hmac.compare_digest(expected,actual):
  with ledger.db:
   failures=int(get(ledger,'pin_failures',0))+1;put(ledger,'pin_failures',failures)
   if failures>=5:put(ledger,'pin_locked_until',time.time()+30);put(ledger,'pin_failures',0)
  raise ValidationError('Incorrect passcode.')
 with ledger.db:put(ledger,'pin_failures',0);put(ledger,'pin_locked_until',0)
def save(ledger,name,pin,current_pin=None):
 name=required_text(name,'Name',80);valid_pin(pin)
 if get(ledger,'reset_pin'):verify(ledger,current_pin)
 salt=secrets.token_bytes(16);digest=hashlib.pbkdf2_hmac('sha256',pin.encode(),salt,180000).hex()
 with ledger.db:put(ledger,'profile_name',name);put(ledger,'reset_pin',salt.hex()+':'+digest)
 return status(ledger)
def authorize(ledger,pin):
 verify(ledger,pin);token=secrets.token_urlsafe(32)
 with ledger.db:put(ledger,'reset_token',hashlib.sha256(token.encode()).hexdigest());put(ledger,'reset_token_until',time.time()+180)
 return {'token':token}
def check_token(ledger,token):
 if not isinstance(token,str) or float(get(ledger,'reset_token_until',0))<time.time() or not hmac.compare_digest(get(ledger,'reset_token',''),hashlib.sha256(token.encode()).hexdigest()):raise ValidationError('Reset authorization expired. Enter your passcode again.')
 return {'valid':True}
def clear(ledger,token):
 check_token(ledger,token)
 from backend.bank_sync import BankSync, LOCK
 with LOCK:
  for environment,table in [('sandbox','bank_stage'),('production','bank_stage_production')]:
   exists=ledger.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone()
   if exists and ledger.db.execute('SELECT 1 FROM '+table).fetchone():BankSync(ledger,environment=environment).disconnect()
 custom=get(ledger,'custom_accounts')=='1' or os.environ.get('BASIH_EDITION') in ('test','shared')
 # This function is invoked only by the explicit reset action, never by packaging.
 ledger.db.execute('PRAGMA secure_delete = ON')
 tables={r[0] for r in ledger.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
 with ledger.db:
  for table in ['revisions','events','person_notes','people','imported_events','history_edits','manual_pnc','source_history','notes_rows','notes_batches','apple_card_imports']:
   if table in tables:ledger.db.execute('DELETE FROM '+table)
  ledger.db.execute('DELETE FROM accounts')
  ledger.db.execute('DELETE FROM categories')
  ledger.db.executemany('INSERT INTO categories(name,position) VALUES(?,?)',((name,index) for index,name in enumerate(CATEGORIES)))
  for entry in (() if custom else DEFAULT_ACCOUNTS):ledger.db.execute('INSERT INTO accounts(id,name,kind,default_payment_account) VALUES(?,?,?,?)',entry)
  ledger.db.execute('DELETE FROM meta')
  put(ledger,'user_cleared_data','1')
  if custom:put(ledger,'custom_accounts','1')
 return {'cleared':True}

def set_opening(ledger,account_id,value):
 cents(value,'Opening balance')
 if account_id not in ledger.accounts():raise ValidationError('Choose an account.')
 if ledger.accounts()[account_id]['opening_cents'] is not None:raise ValidationError('This account already has an opening balance. Choose a new account or correct its original opening in Raw mode.')
 with ledger.db:
  changed=ledger.db.execute('UPDATE accounts SET opening_cents=? WHERE id=? AND opening_cents IS NULL',(value,account_id))
  if changed.rowcount!=1:raise ValidationError('Opening balance changed; reload.')
 return account_id
