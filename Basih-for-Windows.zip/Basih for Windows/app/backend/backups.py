"""Local backup catalogue; saved outside the ledger so resets retain it."""
import hashlib, json, os, sqlite3, tempfile
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4
from backend import settings
from backend.ledger import Ledger, ValidationError


def directory(ledger):
    return Path(ledger.path).resolve().parent / 'backups'


def create(ledger, reason='Saved backup', export_path=None):
    folder=directory(ledger);folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    stamp=datetime.now(timezone.utc).isoformat()
    target=folder/(datetime.now().strftime('Basih-%Y%m%d-%H%M%S-')+uuid4().hex[:8]+'.sqlite3')
    try:
        with sqlite3.connect(target) as dest:ledger.db.backup(dest)
        os.chmod(target,0o600)
        target.with_suffix('.json').write_text(json.dumps({'created_at':stamp,'reason':reason,'export_path':export_path}))
        os.chmod(target.with_suffix('.json'),0o600)
    except Exception:
        target.unlink(missing_ok=True);raise
    return target


def candidates(ledger):
    roots=[directory(ledger)]
    # Existing project backups remain read-only. Packaged apps do not scan unrelated folders.
    project=Path(__file__).resolve().parents[1]/'backup'
    if project.is_dir():roots.append(project)
    paths={p.resolve() for root in roots if root.is_dir() for p in root.rglob('*.sqlite3') if not p.is_symlink()}
    registry=directory(ledger).parent/'backup-locations.json'
    if registry.is_file():
        try:
            paths.update(Path(p).resolve() for p in json.loads(registry.read_text()) if isinstance(p,str) and Path(p).is_file() and not Path(p).is_symlink())
        except (ValueError,OSError):pass
    return sorted(paths)


def identifier(path):return hashlib.sha256(str(path).encode()).hexdigest()


def listing(ledger):
    result=[]
    for path in candidates(ledger):
        try:
            with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as db:
                row=db.execute("SELECT value FROM meta WHERE key='profile_name'").fetchone()
            info=json.loads(path.with_suffix('.json').read_text()) if path.with_suffix('.json').is_file() else {}
            result.append({'id':identifier(path),'owner':row[0] if row else 'Unknown owner','path':str(path),
                'date':info.get('created_at',datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat()),
                'export_path':info.get('export_path'),'date_kind':'Created' if info.get('created_at') else 'Last modified','reason':info.get('reason','Existing backup')})
        except (sqlite3.Error,OSError,ValueError):continue
    return sorted(result,key=lambda x:x['date'],reverse=True)


def restore(ledger,backup_id,pin):
    # Verify against the active profile (rate limited) before reading backup data.
    if settings.get(ledger,'reset_pin'):settings.verify(ledger,pin)
    path=next((p for p in candidates(ledger) if identifier(p)==backup_id),None)
    if path is None:raise ValidationError('Backup is no longer available at its saved location.')
    if path.stat().st_size>100*1024*1024:raise ValidationError('Backup is too large.')
    with tempfile.TemporaryDirectory() as temp:
        target=Path(temp)/'restore.sqlite3'
        try:
            with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as source:
                if source.execute("SELECT 1 FROM sqlite_master WHERE type IN ('trigger','view')").fetchone():raise ValidationError('Unsupported backup schema.')
                if source.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValidationError('Backup is damaged.')
                stored=source.execute("SELECT value FROM meta WHERE key='reset_pin'").fetchone()
                if not stored:raise ValidationError('This backup has no passcode; it needs a separate legacy recovery.')
                settings.verify(ledger,pin,stored_hash=stored[0])
                with sqlite3.connect(target) as copy:source.backup(copy)
            restored=Ledger(target)
            try:
                restored.snapshot()
                if restored.db.execute('PRAGMA foreign_key_check').fetchone():raise ValidationError('Backup has broken record links.')
                # Short-lived reset authorizations must never survive recovery.
                with restored.db:
                    restored.db.execute("DELETE FROM meta WHERE key IN ('reset_token','reset_token_until')")
                    settings.put(restored,'user_cleared_data','1')
                safety=create(ledger,'Before restore')
                restored.db.backup(ledger.db)
            finally:restored.close()
        except (sqlite3.Error,KeyError,TypeError,ValueError,OSError) as exc:
            if isinstance(exc,ValidationError):raise
            raise ValidationError('This is not a usable Basih backup.') from None
    return {'restored':True,'safety_backup':str(safety)}
