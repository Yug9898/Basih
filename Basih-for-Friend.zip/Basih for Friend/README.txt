Basih for Mac — 1.0002.00.21

Unzip, then double-click Install Basih.command.
Apple Silicon Macs on macOS 26 or later receive native My Basih.
Older supported Apple Silicon Macs retain the compatible Basih interface.

The installer verifies the new application before replacing an old Desktop copy.
Existing Basih Shared records and backups remain in Application Support.
The original Basih data folder is copied only if Basih Shared does not yet exist.

Restore another backup in Settings > Backups > Choose backup…
Choose your SQLite backup, enter its passcode, and confirm restoration.
A safety backup is saved first. The selected original backup remains intact.
Plaid/Tavily credentials stay in this Mac's Keychain, not in the download or backup.
macOS may request permission to access existing Keychain items again.

Touch ID in this unsigned-for-distribution build may require developer provisioning;
use your existing Basih passcode if macOS cannot enable biometric storage.
Review, statement PDF review, and Assistant use the native SwiftUI interface on macOS 26 or later.
The older macOS compatibility app keeps the legacy interface.
