"""Read-only imported evidence and transparent comparison, separate from postings."""
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
from backend.ledger import ValidationError, account_purchase_delta

ACCOUNT_IDS = ('B1','B2','CC1','CC2','CC3')
SPENDING = ('Food','Grocery','Rent','Tuition','Travel','Shopping','Other','Subscription','Debited')


def exact_cents(value):
    """Remove float serialization noise only. Never round genuine fractional cents."""
    if type(value) not in (int,float): return None
    scaled=Decimal(str(value))*100
    integral=scaled.to_integral_value()
    if abs(scaled-integral)>Decimal('0.000001'): return None
    return int(integral)


def seed_history(ledger, path):
    """Idempotent archive import. Does not change accounts, people, or events."""
    payload=json.loads(Path(path).read_text())
    if payload.get('schema_version') != 1: raise ValidationError('Unsupported history format.')
    digest=payload.get('sha256')
    if not isinstance(digest,str) or len(digest)!=64: raise ValidationError('History needs a source fingerprint.')
    raw=json.dumps(payload,sort_keys=True,ensure_ascii=False)
    ledger.db.execute('CREATE TABLE IF NOT EXISTS history_edits (source_sha256 TEXT NOT NULL, source_row INTEGER NOT NULL, revision INTEGER NOT NULL, recorded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, inputs TEXT NOT NULL, PRIMARY KEY(source_sha256,source_row,revision))')
    ledger.db.execute('CREATE TABLE IF NOT EXISTS source_history (sha256 TEXT PRIMARY KEY, content_hash TEXT NOT NULL, imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, payload TEXT NOT NULL)')
    ledger.db.execute('CREATE TABLE IF NOT EXISTS manual_pnc (source_row INTEGER NOT NULL, revision INTEGER NOT NULL, balance_cents INTEGER NOT NULL, recorded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(source_row,revision))')
    for table in payload['tables']:
        if table['id']=='26-27 calc::Universal':
            for row in table['rows']:
                if 2<=row['row']<=9:
                    value=exact_cents(row['values'][8])
                    if value is not None: ledger.db.execute('INSERT OR IGNORE INTO manual_pnc(source_row,revision,balance_cents) VALUES(?,0,?)',(row['row'],value))
    ledger.db.commit()
    content_hash=hashlib.sha256(raw.encode()).hexdigest()
    existing=ledger.db.execute('SELECT content_hash FROM source_history WHERE sha256=?',(digest,)).fetchone()
    if existing and existing[0]!=content_hash:
        previous=json.loads(ledger.db.execute('SELECT payload FROM source_history WHERE sha256=?',(digest,)).fetchone()[0])
        if previous.get('tables')!=payload.get('tables'):raise ValidationError('Same source fingerprint has different extracted history; review before replacing it.')
        ledger.db.execute('UPDATE source_history SET payload=?,content_hash=? WHERE sha256=?',(raw,content_hash,digest))
    with ledger.db:
        ledger.db.execute('INSERT OR IGNORE INTO source_history(sha256,content_hash,payload) VALUES(?,?,?)',(digest,content_hash,raw))


def has_history(ledger):
    if not ledger.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='source_history'").fetchone(): return False
    return ledger.db.execute('SELECT 1 FROM source_history').fetchone() is not None


def history_snapshot(ledger):
    if not has_history(ledger): return None
    payload=json.loads(ledger.db.execute('SELECT payload FROM source_history ORDER BY imported_at DESC,rowid DESC LIMIT 1').fetchone()[0])
    universal=next(t for t in payload['tables'] if t['id']=='26-27 calc::Universal')
    edits = {r['source_row']: r for r in ledger.db.execute('SELECT * FROM history_edits WHERE source_sha256=? ORDER BY revision', (payload['sha256'],))}
    for entry in universal['rows']:
        if entry['row'] in edits:
            entry['values'][:6] = json.loads(edits[entry['row']]['inputs'])
    replay={k:0 for k in ACCOUNT_IDS}
    rows=[];week=None
    for entry in universal['rows'][:-1]:  # last row is the aggregate footer, never another posting
        values=entry['values']
        if isinstance(values[0],(int,float)): week=int(values[0])
        meaningful=any(value is not None for value in values[:6])
        if not meaningful: continue
        source_effects={k:exact_cents(values[c]) or 0 for k,c in zip(ACCOUNT_IDS,[7,9,11,13,15])}
        cached={k:exact_cents(values[c]) for k,c in zip(ACCOUNT_IDS,[8,10,12,14,16])}
        for key,change in source_effects.items(): replay[key]+=change
        rowno=entry['row'];amount=exact_cents(values[1]);account=values[4];category=values[5]
        explanations=[];direct_effects={};review=[]
        if category=='Opening balance':
            review.append('Opening entry is preserved; verify the effective baseline/date before posting.')
        elif category in SPENDING and amount is not None and amount>0 and account in ACCOUNT_IDS:
            direct_effects={account:account_purchase_delta(amount,'card' if account.startswith('CC') else 'bank')}
            explanations.append(f'{account}: full purchase amount affects '+('card debt' if account.startswith('CC') else 'bank cash')+'.')
            review.append('Personal share and person identities are not inferred from Debit.')
        elif category in ('CP1','CP2','CP3') and amount is not None:
            review.append('Card payment amount is known; confirm its bank source before posting.')
        elif category=='Transfer':
            review.append('Confirm the destination and link its corresponding receipt to avoid double counting.')
        elif category=='Deposit':
            review.append('Confirm whether this receipt is external income, repayment, or an internal transfer.')
        else: review.append('Preserved source row; confirm its event purpose before posting.')
        if values[2] is not None: review.append('Raw Debit is retained as evidence; no Debit rule is applied.')
        if isinstance(values[1],str): review.append('Text note, not a numeric account transaction; cash account/settlement needs confirmation.')
        # Card debt sign is opposite to legacy credit-card effect signs.
        direct_comparison={k:(-source_effects[k] if k.startswith('CC') else source_effects[k]) for k in direct_effects}
        direct_match=bool(direct_effects) and direct_effects==direct_comparison
        if direct_effects and not direct_match: review.append('Full-amount account effect differs from the source effect; keep this row unresolved.')
        start=(date(2026,8,23)+timedelta(weeks=(week or 1)-1)).isoformat() if week is not None and category!='Opening balance' else None
        rows.append({'id':f'{payload["sha256"]}:Universal:{rowno}','source_row':rowno,'values':values,'edit_revision':edits[rowno]['revision'] if rowno in edits else 0,
                     'description':values[3] or (values[1] if isinstance(values[1],str) else 'Untitled source entry'),
                     'account':account,'category':category,'amount_cents':amount,'week':week,'week_start':start,
                     'date_precision':'week' if start else 'unknown','raw_debit':values[2],
                     'source_effects':source_effects,'source_running':cached,'replayed_source_balances':replay.copy(),
                     'source_differences':{k:cached[k]-replay[k] if cached[k] is not None else None for k in ACCOUNT_IDS},
                     'independent_purchase_effects':direct_effects,'independent_effect_matches_source':direct_match,
                     'calculation_notes':explanations,'review_notes':review,'personal_cents':(0 if category=='Debited' else amount-exact_cents(values[2]) if exact_cents(values[2]) is not None and 0<exact_cents(values[2])<=amount else amount if values[2] is None or (exact_cents(values[2]) is not None and exact_cents(values[2])<=0) else None) if direct_effects else None,'person_effects':None})
    ending=universal['rows'][-1]['values']
    cached_ending={k:exact_cents(ending[c]) for k,c in zip(ACCOUNT_IDS,[8,10,12,14,16])}
    return payload | {'transactions':rows,'comparison':{
        'recorded_effect_totals':replay,'cached_ending_balances':cached_ending,
        'differences':{k:cached_ending[k]-replay[k] if cached_ending[k] is not None else None for k in ACCOUNT_IDS},
        'independent_purchase_checks':sum(r['independent_effect_matches_source'] for r in rows),
        'independent_purchase_mismatches':[r['source_row'] for r in rows if r['independent_purchase_effects'] and not r['independent_effect_matches_source']],
        'explanation':'Comparison sums recorded account-effect values, in source order and source signs. It does not evaluate Debit or reproduce Numbers formulas. These are source-history comparisons, not bank-verified app balances.'}}

CUTOVER = '2026-10-10'


def migrate_confirmed_inputs(ledger, rebuild=False):
    """User-authorized input interpretation, never evaluates Numbers formulas.
    Historical person allocations remain unknown; current Notes are the cutover baseline.
    """
    initialized = ledger.db.execute("SELECT 1 FROM meta WHERE key='real_history_migrated'").fetchone() is not None
    rule_version = ledger.db.execute("SELECT value FROM meta WHERE key='history_rule_version'").fetchone()
    if initialized and not rebuild and rule_version and rule_version['value']=='3':
        confirm_pnc(ledger)
        return
    if initialized: rebuild=True
    if not has_history(ledger): return
    if not initialized and (ledger.db.execute('SELECT 1 FROM events').fetchone() or ledger.people()):
        raise ValidationError('Real-history initialization needs a separate empty ledger, not demo or existing entries.')
    archive = history_snapshot(ledger)
    rows=archive['transactions']; skip=set(); imported=[]
    openings={key:None for key in ACCOUNT_IDS}; opening_seen=set()
    for index,row in enumerate(rows):
        values=row['values']; category=row['category']; account=row['account']; amount=row['amount_cents']; debit=exact_cents(row['raw_debit'])
        if row['id'] in skip or account not in ACCOUNT_IDS: continue
        if category=='Opening balance':
            if account in opening_seen: raise ValidationError(f'Duplicate opening for {account}; review the raw correction.')
            opening_seen.add(account)
            if amount is not None: openings[account]=amount
            continue
        account_effects={}; personal=0; reported_kind='source_note'; text=row['description']; notes=[]
        if category=='Transfer' and amount is not None:
            if index+1>=len(rows): raise ValidationError('Transfer destination missing.')
            nextrow=rows[index+1]
            if nextrow['category']!='Deposit' or nextrow['amount_cents']!=amount or nextrow['account']==account or nextrow['account'] not in ('B1','B2'):
                raise ValidationError(f'Transfer at row {row["source_row"]} needs destination confirmation.')
            account_effects={account:-amount,nextrow['account']:amount};skip.add(nextrow['id']);reported_kind='transfer'
            notes.append(f'Paired source rows {row["source_row"]} and {nextrow["source_row"]}; no income or spending.')
        elif category in ('CP1','CP2','CP3') and amount is not None:
            bank='B1' if category=='CP1' else 'B2'
            account_effects={account:-amount,bank:-amount};reported_kind='card_payment'
            notes.append(f'Payment source {bank}: user default plus recorded bank-effect evidence; debt reduces by payment amount.')
        elif category=='Deposit' and amount is not None:
            account_effects={account:amount};reported_kind='deposit_purpose_unconfirmed'
            notes.append('A recorded receipt is not automatically external income. Purpose is unconfirmed.')
        elif category in SPENDING and amount is not None and amount>0:
            account_effects={account:account_purchase_delta(amount,'card' if account.startswith('CC') else 'bank')}
            reported_kind='purchase'
            if category=='Debited':
                personal=0
                notes.append('Recorded lending/other-person purchase, excluded from personal spending; current person balance is your Notes snapshot.')
            elif debit is not None and debit>0 and debit<=amount:
                personal=amount-debit
                notes.append('User-confirmed positive Debit is collectible; full purchase remains on the account.')
            elif row['raw_debit'] is None or (debit is not None and debit<=0):
                personal=amount
                notes.append('Personal share uses your declared rule: no collectible Debit means your own purchase. Reviewable if the source entry was mistaken.')
            else:
                personal=None
                notes.append('Non-numeric Debit annotation does not establish a personal share; review this row.')
        elif amount not in (None,0):
            raise ValidationError(f'Unsupported amount/category at source row {row["source_row"]}.')
        if debit is not None and debit<0:
            # Separate immutable receipt: never alters a purchase, even when on the same source row.
            received=-debit
            receipt_effect={account:-received if account.startswith('CC') else received}
            receipt={ 'id':row['id']+':receipt','date':row['week_start'],'date_precision':'week', 'description':text+' · repayment received',
                      'kind':'historical','original_kind':'repayment_received','status':'posted','amount_cents':received,
                      'personal_cents':0,'effects':{'accounts':receipt_effect,'people':{},'spending_cents':0},
                      'source_row':row['source_row'],'source_sha256':archive['sha256'],
                      'calculation_notes':['Negative Debit interpreted from the user’s explicit rule, not from a spreadsheet formula.',
                        'Current person balances come from the Notes cutover; no historical person allocation is guessed.']}
        else: receipt=None
        if account_effects:
            imported.append({'id':row['id']+':movement','date':row['week_start'],'date_precision':'week','description':text,
                'kind':'historical','original_kind':reported_kind,'status':'posted','amount_cents':amount or 0,
                'category':'Subscriptions' if category=='Subscription' else category,
                'personal_cents':personal,'effects':{'accounts':account_effects,'people':{},'spending_cents':personal},
                'source_row':row['source_row'],'source_sha256':archive['sha256'],'calculation_notes':notes})
        if receipt: imported.append(receipt)
    if 'CC3' not in opening_seen:
        openings['CC3']=0
    ledger.db.execute('CREATE TABLE IF NOT EXISTS imported_events (seq INTEGER PRIMARY KEY, id TEXT UNIQUE NOT NULL, entered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, payload TEXT NOT NULL)')
    with ledger.db:
        if rebuild: ledger.db.execute('DELETE FROM imported_events')
        for account,opening in openings.items():
            ledger.db.execute('UPDATE accounts SET opening_cents=? WHERE id=?',(opening,account))
        imported_at=ledger.db.execute('SELECT imported_at FROM source_history WHERE sha256=?',(archive['sha256'],)).fetchone()[0]
        for index,event in enumerate(imported):
            ledger.db.execute('INSERT INTO imported_events(seq,id,entered_at,payload) VALUES(?,?,?,?)',(index+1,event['id'],imported_at,json.dumps(event)))
        for name,balance in ([] if initialized else archive.get('current_notes',[])):
            ledger.db.execute('INSERT INTO people(id,name,opening_cents) VALUES(?,?,?)',('notes:'+name.lower(),name,balance))
        ledger.db.execute("INSERT OR IGNORE INTO meta VALUES('real_history_migrated',?)",(archive['sha256'],))
        ledger.db.execute("INSERT OR IGNORE INTO meta VALUES('notes_cutover',?)",(CUTOVER,))
        ledger.db.execute("INSERT OR REPLACE INTO meta VALUES('history_rule_version','3')")
        if archive.get('profile_name'):ledger.db.execute("INSERT OR IGNORE INTO meta VALUES('profile_name',?)",(archive['profile_name'],))
        if 'CC3' not in opening_seen:
            ledger.db.execute("INSERT OR REPLACE INTO meta VALUES('cc3_opening_basis','Provisional $0 opening for a newly issued card; verify against its first statement.')")
        else: ledger.db.execute("DELETE FROM meta WHERE key='cc3_opening_basis'")
    confirm_pnc(ledger)
    return len(imported)


def correct_history_row(ledger, row_number, inputs, expected_revision):
    if not isinstance(inputs,list) or len(inputs)!=6: raise ValidationError('Exactly the six raw input columns are editable.')
    archive=history_snapshot(ledger)
    original=next((r for r in archive['transactions'] if r['source_row']==row_number),None)
    if original is None: raise ValidationError('Source input row not found.')
    current=original['edit_revision']
    if type(expected_revision) is not int or expected_revision!=current: raise ValidationError('This row changed; reload before editing.')
    week,amount,debit,description,account,category=inputs
    if week is not None and (type(week) is not int or not 1<=week<=53): raise ValidationError('Week must be an integer 1–53 or blank.')
    for value in (amount,debit):
        if value is not None and (exact_cents(value) is None or abs(exact_cents(value))>10**12):
            # The original free-text cash note remains a preserved note.
            if value != original['values'][1] or not isinstance(value,str): raise ValidationError('Amounts must be exact cents or blank.')
    if amount is not None and isinstance(amount,(int,float)) and amount<0: raise ValidationError('Purchase Amount must not be negative; use explicit event purpose.')
    if account not in ACCOUNT_IDS: raise ValidationError('Choose a known account.')
    if (original['category']=='Opening balance') != (category=='Opening balance'): raise ValidationError('Opening entries keep their role; edit their amount/account without changing them into another event kind.')
    if category in ('CP1','CP2','CP3') and account != {'CP1':'CC1','CP2':'CC2','CP3':'CC3'}[category]: raise ValidationError('Card payment category must identify the selected card.')
    if category not in SPENDING+('Opening balance','Deposit','Transfer','CP1','CP2','CP3','Debit'): raise ValidationError('Unknown source category.')
    if description is not None and (not isinstance(description,str) or len(description)>300): raise ValidationError('Description must be text up to 300 characters.')
    if type(debit) in (int,float) and debit>0 and type(amount) in (int,float) and debit>amount: raise ValidationError('Collectible share cannot exceed the purchase total.')
    # Validate on a disposable clone before committing a revision and rebuilt projections.
    from backend.ledger import Ledger
    clone=Ledger(':memory:')
    ledger.db.backup(clone.db)
    try:
        clone.db.execute('INSERT INTO history_edits(source_sha256,source_row,revision,inputs) VALUES(?,?,?,?)',
            (archive['sha256'],row_number,current+1,json.dumps(inputs)))
        clone.db.commit()
        migrate_confirmed_inputs(clone,rebuild=True)
        replacements=[dict(r) for r in clone.db.execute('SELECT * FROM imported_events ORDER BY seq')]
        openings=clone.accounts()
    finally: clone.close()
    with ledger.db:
        inserted=ledger.db.execute('INSERT INTO history_edits(source_sha256,source_row,revision,inputs) SELECT ?,?,?,? WHERE COALESCE((SELECT MAX(revision) FROM history_edits WHERE source_sha256=? AND source_row=?),0)=?',
            (archive['sha256'],row_number,current+1,json.dumps(inputs),archive['sha256'],row_number,current))
        if inserted.rowcount!=1: raise ValidationError('This row changed; reload before editing.')
        ledger.db.execute('DELETE FROM imported_events')
        for row in replacements: ledger.db.execute('INSERT INTO imported_events(seq,id,entered_at,payload) VALUES(?,?,?,?)',(row['seq'],row['id'],row['entered_at'],row['payload']))
        for key,account in openings.items(): ledger.db.execute('UPDATE accounts SET opening_cents=? WHERE id=?',(account['opening_cents'],key))
    return current+1


def explain(ledger, question):
    state=ledger.snapshot(); archive=history_snapshot(ledger)
    q=question.lower();cash=lambda n: f'${abs(n)/100:,.2f}'
    if any(word in q for word in ('owe','people','person','notes')):
        return {'answer':'Current Notes balances, plus entries after the October 10 cutover: '+ '; '.join(p['name']+(' owes you ' if (p['posted_balance_cents'] or 0)>=0 else ' is owed ')+cash(p['posted_balance_cents'] or 0) for p in state['people'])+'. Historical repayments are not deducted a second time.', 'basis':'Your supplied Notes balances and subsequent person effects.'}
    if any(word in q for word in ('spend','share','food','grocery')):
        return {'answer':f'Your declared entry rules produce personal spending of {cash(state["personal_spending_cents"])}. {state["unknown_personal_shares"]} historical purchase shares are unconfirmed, so this is an incomplete spending total. Repayments, transfers and card payments add no spending.', 'basis':'Sum of confirmed personal cents; unknown shares are excluded and counted.'}
    if any(word in q for word in ('balance','pnc','32','difference','bank')) and archive:
        balances={a['id']:a for a in state['accounts']}
        current='; '.join(a['name']+': '+((('-' if a['kind']=='card' and a['posted_balance_cents']>0 else '-' if a['kind']=='bank' and a['posted_balance_cents']<0 else '')+cash(a['posted_balance_cents'])) if a['posted_balance_cents'] is not None else 'unknown opening, '+cash(a['posted_movement_cents'])+' recorded change')+(' debt' if a['kind']=='card' else ' cash') for a in state['accounts'])
        return {'answer':'Current app balances: '+current+'. Original reconstructed PNC: '+cash(archive['comparison']['recorded_effect_totals']['B1'])+'; source PNC: '+cash(archive['comparison']['cached_ending_balances']['B1'])+'. The original cumulative chain I15 skips the Olive Garden row. The entry is retained. Confirmed checkpoints apply separately from spending.', 'basis':'Current account projections and preserved source account arithmetic.'}
    if any(word in q for word in ('debit','repay','payment','transfer')):
        return {'answer':'Positive Debit records an amount to collect without reducing the purchase’s account effect. Negative Debit creates a separate repayment receipt. Transfers move cash between accounts; card payments reduce cash and card debt by the payment amount. Neither creates personal spending or income.', 'basis':'Your explicitly confirmed input meanings and independent account/spending/person effects.'}
    return {'answer':'I can explain account balances and differences, what people owe, personal spending, or repayments and transfers. Choose a topic or include one of those subjects in your question.', 'basis':'Local calculation explanations; no cloud AI or unsupported inference.'}


def history_row_revisions(ledger, row_number):
    stored=ledger.db.execute('SELECT payload FROM source_history ORDER BY imported_at DESC,rowid DESC LIMIT 1').fetchone()
    if not stored: return []
    original=json.loads(stored[0]); table=next(t for t in original['tables'] if t['id']=='26-27 calc::Universal')
    row=next((r for r in table['rows'] if r['row']==row_number),None)
    if row is None: return []
    return [{'revision':0,'recorded_at':'Original Numbers input','inputs':row['values'][:6]}]+[
        dict(r)|{'inputs':json.loads(r['inputs'])} for r in ledger.db.execute('SELECT revision,recorded_at,inputs FROM history_edits WHERE source_sha256=? AND source_row=? ORDER BY revision',(original['sha256'],row_number))]


def correct_manual_pnc(ledger, source_row, balance_cents, expected_revision):
    from backend.ledger import cents
    cents(balance_cents,'Manual PNC balance')
    if not 2<=source_row<=9: raise ValidationError('PNC is manual only through source row 9.')
    existing=ledger.db.execute('SELECT MAX(revision) FROM manual_pnc WHERE source_row=?',(source_row,)).fetchone()[0]
    if existing is None or expected_revision!=existing: raise ValidationError('Manual value changed; reload before editing.')
    with ledger.db:
        ledger.db.execute('INSERT INTO manual_pnc(source_row,revision,balance_cents) VALUES(?,?,?)',(source_row,existing+1,balance_cents))
    return existing+1


def confirm_pnc(ledger):
    """User-confirmed balance stored with private source data, never in the shared engine."""
    archive=history_snapshot(ledger)
    checkpoint=archive.get('confirmed_balances',{}).get('B1') if archive else None
    with ledger.db:
        if checkpoint:ledger.db.execute("INSERT OR IGNORE INTO meta VALUES('pnc_confirmed_checkpoint',?)",(json.dumps(checkpoint),))
        if archive and archive.get('profile_name'):ledger.db.execute("INSERT OR IGNORE INTO meta VALUES('profile_name',?)",(archive['profile_name'],))
