Basih for Windows

1. Unzip the entire folder.
2. Double-click “Install Basih.cmd”. Approve the Windows prompt if one appears.
3. Setup downloads the official 64-bit Python runtime from python.org, installs Basih under your Windows user profile, creates a Desktop shortcut, and opens the app.
4. Basih data stays in %LOCALAPPDATA%\Basih. Plaid credentials are encrypted for your Windows account using Windows Data Protection.

Open the Basih Desktop shortcut after installation. Basih uses Edge or Chrome
in a dedicated app window without a browser address bar or tabs. Either browser
must be installed. It will not fall back to opening a normal browser page.
For an update, download the latest Windows ZIP and run Install Basih.cmd again.
Your existing data stays in place. Mac's in-app updater is not available on Windows.

If Basih cannot start, it displays the location of startup-error.txt. Send that
small text file to the developer; it contains the technical error, not your ledger.

No Yug transactions, balances, notes, backups, or credentials are included.

For bank history, first choose “Start my ledger from” in Settings → Bank Sync. Transactions on that date are included. Basih calculates the opening balance immediately before them from the current bank balance and the history Plaid returned. Plaid may return less history than requested, so compare the oldest downloaded transaction before trusting the opening balance.

Use your own Plaid Client ID and Production secret. Complete Plaid’s secure connection page, return to Basih, choose Check connection, then review uncertain entries.
