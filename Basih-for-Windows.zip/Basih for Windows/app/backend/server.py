"""Loopback-only local JSON API and built frontend, with stdlib runtime."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import sqlite3,tempfile,secrets,hmac,threading
from backend import settings, backups
from backend import bank_sync
import sys
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from backend.ledger import Ledger, ValidationError
from backend.history import seed_history, history_snapshot, has_history, migrate_confirmed_inputs, correct_history_row, explain, history_row_revisions, correct_manual_pnc

from backend.reports import summary
from backend.notes_import import preview as preview_notes, commit as commit_notes
from backend.apple_card_import import preview as preview_apple_card, commit as commit_apple_card

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[1]))

def serialized(fn):
    def wrapped(*args, **kwargs):
        with bank_sync.LOCK:return fn(*args, **kwargs)
    return wrapped

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, db_path, **kwargs):
        self.db_path = db_path
        super().__init__(*args, directory=str(ROOT / 'frontend' / 'dist'), **kwargs)

    def reply(self, status, value, cookie=None):
        body = json.dumps(value).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        if cookie is not None: self.send_header('Set-Cookie',cookie)
        self.end_headers(); self.wfile.write(body)

    def session_token(self):
        from http.cookies import SimpleCookie
        try:
            cookie=SimpleCookie();cookie.load(self.headers.get('Cookie',''))
            return cookie['basih_session'].value if 'basih_session' in cookie else None
        except Exception:return None

    def unlocked(self, ledger):
        if not settings.status(ledger)['launch_lock']:return True
        token=self.session_token()
        if not token:return False
        with self.server.session_lock:
            stored=self.server.sessions.get((self.db_path,token))
        pin=stored.get('pin') if isinstance(stored,dict) else stored
        return pin is not None and hmac.compare_digest(pin,settings.get(ledger,'reset_pin',''))

    def viewer(self):
        token=self.session_token()
        if not token:return False
        with self.server.session_lock:stored=self.server.sessions.get((self.db_path,token))
        return isinstance(stored,dict) and stored.get('mode')=='viewer'

    def issue_session(self, ledger, mode='owner'):
        token=secrets.token_urlsafe(32)
        with self.server.session_lock:self.server.sessions[(self.db_path,token)]={'pin':settings.get(ledger,'reset_pin',''),'mode':mode}
        return 'basih_session='+token+'; HttpOnly; SameSite=Strict; Path=/'

    def discard_session(self):
        token=self.session_token()
        if token:
            with self.server.session_lock:self.server.sessions.pop((self.db_path,token),None)
        return 'basih_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'

    @serialized
    def do_GET(self):
        url = urlparse(self.path)
        if not url.path.startswith('/api/'):
            if not (ROOT / 'frontend/dist/index.html').exists():
                return self.reply(503, {'error':'Build the frontend first. See README.md.'})
            return super().do_GET()
        ledger = Ledger(self.db_path)
        try:
            if url.path=='/api/settings':return self.reply(200,settings.status(ledger)|{'locked':not self.unlocked(ledger),'viewer':self.viewer()})
            if not self.unlocked(ledger):return self.reply(423,{'error':'Unlock Basih to continue.'})
            if self.viewer() and url.path not in ('/api/state','/api/reports','/api/history') and not (url.path.startswith('/api/events/') and url.path.endswith('/history')):
                return self.reply(403,{'error':'Viewer Mode is read-only.'})
            if url.path == '/api/banks':
                with bank_sync.LOCK:
                    return self.reply(200, bank_sync.BankSync(ledger).status())
            if url.path=='/api/settings/backups':return self.reply(200,backups.listing(ledger))
            if url.path=='/api/settings/backup':
                target=backups.create(ledger,export_path=self.headers.get('X-Basih-Backup-Location'))
                body=target.read_bytes()
                self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body);return
            if url.path == '/api/reports':
                params={k:v[0] for k,v in parse_qs(url.query).items()}
                try:report=summary(ledger,params.get('through'),params.get('week'),params.get('monthly_basis','tracking'),params.get('year'))
                except (ValueError,OverflowError):return self.reply(400,{'error':'Choose a valid tracking year and date.'})
                return self.reply(200,report)
            if url.path == '/api/state':
                filters = {k: v[0] for k, v in parse_qs(url.query).items()}
                return self.reply(200, ledger.snapshot(filters) | {'has_history': has_history(ledger)})
            if url.path.startswith('/api/history/rows/') and url.path.endswith('/history'):
                return self.reply(200,history_row_revisions(ledger,int(url.path.split('/')[4])))
            if url.path == '/api/explain':
                question=parse_qs(url.query).get('q',[''])[0][:300]
                return self.reply(200, explain(ledger, question))
            if url.path == '/api/history':
                return self.reply(200, history_snapshot(ledger))
            if url.path.startswith('/api/events/') and url.path.endswith('/history'):
                return self.reply(200, ledger.history(url.path.split('/')[3]))
            self.reply(404, {'error':'Not found.'})
        finally: ledger.close()

    @serialized
    def mutate(self, editing=False):
        # Browser cross-origin writes and oversized requests are rejected; no open CORS.
        origin = self.headers.get('Origin')
        if origin and origin not in (f'http://{self.headers.get("Host")}', 'http://localhost:5173', 'http://127.0.0.1:5173'):
            return self.reply(403, {'error':'Cross-origin write rejected.'})
        if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
            return self.reply(415, {'error':'Use application/json.'})
        ledger = Ledger(self.db_path)
        try:
            path = urlparse(self.path).path
            length = int(self.headers.get('Content-Length', '0'))
            maximum=2_100_000 if path.startswith('/api/apple-card/') else 65536
            if not 0 < length <= maximum: raise ValidationError(f'Request must be 1–{maximum} bytes.')
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict): raise ValidationError('Request must be an object.')
            if path=='/api/settings/unlock' and not editing:
                settings.verify(ledger,data.get('pin'))
                return self.reply(200,{'unlocked':True,'viewer':False},self.issue_session(ledger))
            if path=='/api/settings/viewer' and not editing:
                if not settings.status(ledger)['launch_lock']:raise ValidationError('Turn on App Lock before using Viewer Mode.')
                settings.verify(ledger,data.get('pin'))
                return self.reply(200,{'unlocked':True,'viewer':True},self.issue_session(ledger,'viewer'))
            if path=='/api/settings/lock' and not editing:
                return self.reply(200,{'locked':True},self.discard_session())
            if not self.unlocked(ledger):return self.reply(423,{'error':'Unlock Basih to continue.'})
            if self.viewer():return self.reply(403,{'error':'Viewer Mode is read-only.'})
            if not editing and path.startswith('/api/banks/'):
                return self.reply(200, bank_sync.action(ledger, path.rsplit('/', 1)[-1], data))
            if not editing and path=='/api/settings/save':
                result=settings.save(ledger,data.get('name'),data.get('pin'),data.get('current_pin'))
                return self.reply(200,result|{'locked':False},self.issue_session(ledger) if result['launch_lock'] else None)
            elif not editing and path=='/api/settings/restore-backup':
                result=backups.restore(ledger,data.get('id'),data.get('pin'))
                with self.server.session_lock:self.server.sessions.clear()
            elif not editing and path=='/api/settings/authorize':result=settings.authorize(ledger,data.get('pin'))
            elif not editing and path=='/api/settings/check-token':result=settings.check_token(ledger,data.get('token'))
            elif not editing and path=='/api/settings/clear':result=settings.clear(ledger,data.get('token'))
            elif not editing and path=='/api/settings/delete-card':result=settings.delete_card(ledger,data.get('account_id'))
            elif not editing and path=='/api/settings/delete-account':result=settings.delete_account(ledger,data.get('account_id'))
            elif not editing and path=='/api/settings/merge-account':result=settings.merge_account(ledger,data.get('source_id'),data.get('target_id'))
            elif not editing and path=='/api/settings/delete-person':result=settings.delete_person(ledger,data.get('person_id'))
            elif not editing and path=='/api/settings/add-category':result=settings.add_category(ledger,data.get('name'))
            elif not editing and path=='/api/settings/delete-category':result=settings.delete_category(ledger,data.get('name'))
            elif not editing and path=='/api/settings/link-card':result=settings.link_card(ledger,data.get('account_id'),data.get('bank_id'))
            elif not editing and path=='/api/settings/year-basis':result=settings.set_year_basis(ledger,data.get('year_basis'))
            elif not editing and path=='/api/settings/theme':result=settings.set_theme(ledger,data.get('theme'))
            elif not editing and path=='/api/settings/palette':result=settings.set_palette(ledger,data.get('palette'))
            elif not editing and path=='/api/settings/set-lock':
                result=settings.set_lock(ledger,data.get('pin'),data.get('enabled'),data.get('idle_minutes'))
                return self.reply(200,result|{'locked':False},self.issue_session(ledger) if result['launch_lock'] else self.discard_session())
            elif editing and path.startswith('/api/accounts/') and path.endswith('/opening'):result=settings.set_opening(ledger,path.split('/')[3],data.get('opening_cents'))
            elif not editing and path=='/api/notes/preview':
                result=preview_notes(ledger,data.get('text'),data.get('date'))
            elif not editing and path=='/api/notes/import':
                result=commit_notes(ledger,data.get('text'),data.get('date'),data.get('selections'),data.get('batch_id'))
            elif not editing and path=='/api/apple-card/preview':
                result=preview_apple_card(ledger,data.get('text'),data.get('account_id'))
            elif not editing and path=='/api/apple-card/import':
                result=commit_apple_card(ledger,data.get('text'),data.get('account_id'),data.get('fingerprints'))
            elif editing and path.startswith('/api/people/') and path.endswith('/note'):
                result=ledger.save_person_note(path.split('/')[3],data.get('text'),data.get('expected_revision'))
            elif editing and path.startswith('/api/manual-pnc/'):
                result=correct_manual_pnc(ledger,int(path.split('/')[-1]),data.get('balance_cents'),data.get('expected_revision'))
            elif editing and path.startswith('/api/history/rows/'):
                result=correct_history_row(ledger,int(path.split('/')[-1]),data.get('inputs'),data.get('expected_revision'))
            elif editing and path.startswith('/api/events/') and path.endswith('/delete'):
                result=ledger.delete_event(path.split('/')[3],data.get('expected_revision'))
            elif editing and path.startswith('/api/events/') and path.endswith('/restore'):
                result=ledger.restore_event(path.split('/')[3],data.get('expected_revision'))
            elif editing and path.startswith('/api/events/'):
                event_id = path.split('/')[3]
                result = ledger.save_event(data.get('event'), event_id, data.get('expected_revision'))
            elif not editing and path == '/api/events': result = ledger.save_event(data)
            elif not editing and path == '/api/people': result = ledger.add_person(data)
            elif not editing and path == '/api/accounts': result = ledger.add_account(data)
            else: return self.reply(404, {'error':'Not found.'})
            self.reply(200 if editing else 201, result if (path.startswith('/api/notes/') or path.startswith('/api/settings/')) else {'id':result})
        except (ValidationError, json.JSONDecodeError, TypeError, ValueError) as exc:
            self.reply(400, {'error':str(exc)})
        finally: ledger.close()

    def do_POST(self): self.mutate()
    def do_PUT(self): self.mutate(editing=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', default='data/basih.sqlite3')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--history', help='Import a read-only source-history JSON archive; no ledger postings.')
    parser.add_argument('--port', type=int, default=8000)
    args = parser.parse_args()
    path = str((ROOT / args.db).resolve())
    ledger = Ledger(path)
    if args.demo: ledger.seed_demo()
    if args.history and not ledger.db.execute("SELECT 1 FROM meta WHERE key='user_cleared_data'").fetchone():
        seed_history(ledger, args.history)
        migrate_confirmed_inputs(ledger)
    ledger.close()
    server = ThreadingHTTPServer(('127.0.0.1', args.port), partial(Handler, db_path=path))
    server.sessions={};server.session_lock=threading.Lock()
    print(f'Basih: http://127.0.0.1:{server.server_address[1]} | database: {path}', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__ == '__main__': main()
