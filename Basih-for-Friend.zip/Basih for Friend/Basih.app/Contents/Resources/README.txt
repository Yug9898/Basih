# Welcome to Basih

## Open the Mac app

1. Download the Mac ZIP from [github.com/Yug9898/Basih](https://github.com/Yug9898/Basih), unzip it, then double-click **Install Basih.command**. It installs Basih.app on your **Desktop** and opens it. Later, use **Settings → Updates → Update Basih**. The app checks, downloads, verifies, replaces and reopens itself while keeping your entries, passcode and bank connections.
2. Approve macOS access to Desktop if asked. If macOS blocks this locally signed app, Control-click Basih.app on your Desktop and choose **Open**. If macOS blocks the setup file, Control-click **Install Basih.command** and choose **Open**.
3. Enter your name and choose a four-digit passcode when setup appears. The packaged app runs on Apple Silicon Macs and includes its engine; no Python, Node.js, or package installs are required.

## Import your bank history

You do not need a spreadsheet. Create your own [Plaid Dashboard](https://dashboard.plaid.com/) account and obtain Production access. Plaid's [Trial plan](https://plaid.com/docs/account/billing/) is available to eligible new US/Canada teams for up to 10 real bank connections. Do not share your bank login or Plaid secret with anyone.

1. Create your banks and cards in Basih. Then open **Settings → Bank Sync** and choose **Start my ledger from**. This date is inclusive.
2. In Plaid Dashboard → **Keys / API Keys**, find your **Client ID** and **Production secret**.
3. In Basih → **Settings → Bank Sync**, save both. Basih stores the secret in macOS Keychain.
4. Choose **Connect bank**, complete the secure Plaid page, then return and choose **Check connection**. Repeat for each institution.
5. Under **Map accounts**, link each Plaid bank or card to the existing Basih account and save the mappings. Basih calculates its opening balance immediately before the selected date, then imports transactions without creating duplicate accounts.
5. Choose **Sync preview** after initial history loads. Basih creates accounts for connected USD banks and cards. Check **Map accounts** if you want to change one.
6. See every returned transaction under **Home → Bank history**. Clear purchases appear in Activity. Use **Review** for transfers, deposits, card payments, refunds and unclear transactions. These are not treated as spending until you classify them.

Basih requests up to 730 days of history, but a bank can return less. Older records that Plaid cannot provide must be entered another way. Sync runs when the app opens and on demand; new transactions may take time to reach Plaid.

## First entries

- Choose **Add Entry → Opening balance** to set the starting balance of each bank/card before its recorded entries. A card's debt is shown as negative; a credit is positive.
- Use **Add account** for an additional account and **Add person** for someone you share expenses with.
- Use **Add Entry** for purchases, repayments, card payments, deposits, transfers or amounts you owe.
- CP1 pays CC1 from B1; CP2 pays CC2 from B2; CP3 pays CC3 from B2.
- Use **Paste from Notes** to paste five columns: Amount, Debit, Description, Account, Category. Preview and select the rows to save. Pasted entries use the day of import.
- Positive Debit is a share to collect; negative Debit is a repayment received. Select the person when asked. A transfer and its matching receipt are posted once.
- **Raw mode** shows entries and their calculations on desktop. **Analysis** has interactive charts.
- Notes below people are optional text and do not change balances.

## Edit, delete and back up

Open an entry's correction form to edit or delete it. Delete removes its effects; Undo is offered and revisions remain stored until a full reset.

Your live database is separate from Basih.app:
`~/Library/Application Support/Basih/basih.sqlite3`

Use **Settings → Save data backup** before resetting. Zipping the app alone does not back up your entries. Keep the backup private; it contains your data.

To restore a saved database: quit Basih, open its data folder through Finder → Go → Go to Folder, preserve the current database separately, copy your backup there as **basih.sqlite3**, and reopen the app.

## Reset and share

In Settings, set a passcode first. Save a data backup, confirm you have it, enter your passcode, then choose **Clear all data & restart setup**.

This clears your records and removes bundled private history from the Mac app. Setup appears again. Quit at this point, before entering another profile, if you want to share a clean app.

In Finder, right-click Basih.app and choose Compress. Send that clean app ZIP; do not include your database backup or data folder. Include this README if you zip a folder containing the app.

The guide is also available in the app's Help menu. No live user database is bundled in the app. Changing the app's name or duplicating it on the same Mac does not create a separate data folder.

## Terminal and source packages

To open Terminal: press Command–Space, type Terminal, and press Return. Or use Finder → Applications → Utilities → Terminal.

You only need development packages if running or rebuilding the source. Install Python 3.12+ from https://www.python.org/downloads/macos/ and Node.js 22.22+ from https://nodejs.org/en/download.

From the project folder:
```sh
npm --prefix frontend ci
npm --prefix frontend run build
python3 -m backend.server --db data/local.sqlite3 --port 8000
```
Then open http://127.0.0.1:8000. Stop the local server with Control–C.

The backend needs no pip packages to run. Mac packaging additionally needs Xcode and PyInstaller; Numbers extraction additionally needs numbers-parser. The project README has the complete build steps.
# Linking cards

Add your bank, then add a credit card and choose **Pay from bank**. You can change the link in **Settings → Banks & cards**. Each card displays its CP number; use that category in Add Entry for card payments. Earlier payments keep their original bank when you change the link.

PNC, Chase, and Apple Card names display their bundled logos. Other institutions display initials. Logos work offline.

