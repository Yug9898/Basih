#!/bin/zsh
# Compatible with the existing friend's updater archive layout.
set -eu
setup_dir="${0:A:h}"
desktop_dir="${BASIH_INSTALL_DESKTOP:-$HOME/Desktop}"
major=$(/usr/bin/sw_vers -productVersion)
major="${major%%.*}"
source_app="$setup_dir/My Basih.app"
app_name="My Basih"
apple_silicon=$(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null || print 0)
if [[ -n "${BASIH_INSTALL_DESKTOP:-}" ]]; then
  major="${BASIH_INSTALL_TEST_MACOS:-$major}"
  apple_silicon="${BASIH_INSTALL_TEST_ARM64:-$apple_silicon}"
fi
fail() {
  print -u2 -- "$1"
  if [[ "${BASIH_INSTALL_NO_OPEN:-0}" != "1" ]]; then
    /usr/bin/osascript - "$1" <<'APPLESCRIPT'
on run args
 display alert "Basih setup" message (item 1 of args) as critical
end run
APPLESCRIPT
  fi
  exit 1
}
[[ "$apple_silicon" == "1" && "$major" -ge 26 ]] || fail 'Basih requires an M1-or-later Mac running macOS 26 or later. Your existing app and data have not been changed.'
[[ -d "$source_app" ]] || fail 'The download is incomplete. Keep the installer beside My Basih.app and download again.'
/usr/bin/codesign --verify --deep --strict "$source_app" >/dev/null 2>&1 || fail 'The app failed verification. Download a fresh copy.'
source_id=$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$source_app/Contents/Info.plist")
[[ "$source_id" == 'local.basih.finance.shared' ]] || fail 'This is not the Basih friends package.'
mkdir -p "$desktop_dir"
target_app="$desktop_dir/$app_name.app"
# Only application bundles are replaced. No Application Support or backup path
# is removed. Keep the old bundle until the new one passes verification.
old_apps=()
for candidate in "$target_app" "$desktop_dir/Basih.app"; do
  [[ -e "$candidate" ]] || continue
  (( ${old_apps[(Ie)$candidate]} )) && continue
  id=$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$candidate/Contents/Info.plist" 2>/dev/null) || fail "An unrelated item occupies $candidate. Move it before installing."
  [[ "$id" == 'local.basih.finance.shared' || ( "$candidate" == "$desktop_dir/Basih.app" && "$id" == 'local.basih.finance' ) ]] || fail "An unrelated app occupies $candidate. Move it before installing."
  old_apps+=("$candidate")
done
if [[ -z "${BASIH_INSTALL_DESKTOP:-}" ]]; then
  /usr/bin/osascript -e 'tell application id "local.basih.finance.shared" to quit' >/dev/null 2>&1 || true
fi
for candidate in "${old_apps[@]}"; do
  for attempt in {1..30}; do
    if ! /usr/bin/pgrep -f "$candidate/Contents/MacOS/" >/dev/null 2>&1; then break; fi
    /bin/sleep 1
  done
  /usr/bin/pgrep -f "$candidate/Contents/MacOS/" >/dev/null 2>&1 && fail 'Quit Basih before installing the update.'
done
stage="$desktop_dir/.Basih-install-$$.app"
/usr/bin/ditto "$source_app" "$stage" || fail 'Could not copy the app. Your existing app is retained.'
/usr/bin/codesign --verify --deep --strict "$stage" >/dev/null 2>&1 || { /bin/rm -rf "$stage"; fail 'The copied app failed verification. Your existing app is retained.'; }
rollback="$desktop_dir/.Basih-previous-$$"
mkdir "$rollback"
moved=()
restore() {
  [[ -d "$target_app" ]] && /bin/rm -rf "$target_app"
  for original in "${moved[@]}"; do /bin/mv "$rollback/${original:t}" "$original"; done
}
for candidate in "${old_apps[@]}"; do
  if /bin/mv "$candidate" "$rollback/${candidate:t}"; then moved+=("$candidate"); else
    for original in "${moved[@]}"; do /bin/mv "$rollback/${original:t}" "$original"; done
    fail 'Could not replace the app. Previous copies were restored.'
  fi
done
if ! /bin/mv "$stage" "$target_app" || ! /usr/bin/codesign --verify --deep --strict "$target_app" >/dev/null 2>&1; then restore; fail 'Installation failed. The previous app was restored.'; fi
if [[ "${BASIH_INSTALL_NO_OPEN:-0}" != "1" ]] && ! /usr/bin/open "$target_app"; then restore; fail 'macOS could not open the update. The previous app was restored.'; fi
/bin/rm -rf "$rollback"
print -- "Installed $app_name. Existing Basih Shared data and backups are retained."
