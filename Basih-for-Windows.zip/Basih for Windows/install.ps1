$ErrorActionPreference = 'Stop'
$source = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $env:LOCALAPPDATA 'Programs\Basih'
$runtime = Join-Path $target 'runtime'
try {
  Start-Transcript -Path (Join-Path $source 'basih-install.log') -Force | Out-Null
  Write-Host 'Installing Basih...'
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  New-Item -ItemType Directory -Force -Path $target | Out-Null
  Copy-Item -Recurse -Force (Join-Path $source 'app') $target
  if (!(Test-Path (Join-Path $runtime 'pythonw.exe'))) {
    $archive = Join-Path $env:TEMP 'basih-python.zip'
    Write-Host 'Downloading Python runtime...'
    Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip' -OutFile $archive
    New-Item -ItemType Directory -Force -Path $runtime | Out-Null
    Expand-Archive -Force $archive $runtime
  }
  # Repair partially completed installations as well as new ones.
  $pathConfig = Join-Path $runtime 'python312._pth'
  if (!(Test-Path $pathConfig)) { throw 'Python runtime is incomplete. Its python312._pth file is missing.' }
  if (!((Get-Content $pathConfig) -contains '..\app')) { Add-Content $pathConfig '..\app' }
  Write-Host 'Checking the local engine...'
  & (Join-Path $runtime 'python.exe') -c "import sqlite3; from backend.server import Handler; print('Engine ready')"
  if ($LASTEXITCODE -ne 0) { throw 'The local engine could not load. See the error above.' }
  $start = Join-Path $target 'Start Basih.cmd'
  '@echo off' + "`r`n" + 'cd /d "%~dp0"' + "`r`n" + 'start "Basih" "%~dp0runtime\pythonw.exe" "%~dp0app\desktop\windows_entry.py"' | Set-Content -Encoding ASCII $start
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Basih.lnk'))
  $shortcut.TargetPath = Join-Path $runtime 'pythonw.exe'
  $shortcut.Arguments = '"' + (Join-Path $target 'app\desktop\windows_entry.py') + '"'
  $shortcut.WorkingDirectory = $target
  $shortcut.IconLocation = (Join-Path $env:SystemRoot 'System32\imageres.dll') + ',11'
  $shortcut.Save()
  Start-Process -FilePath $shortcut.TargetPath -ArgumentList $shortcut.Arguments -WorkingDirectory $target
} catch {
  Write-Host "Basih setup could not finish: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
} finally {
  try { Stop-Transcript | Out-Null } catch { }
}
