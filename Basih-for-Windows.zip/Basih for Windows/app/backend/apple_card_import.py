"""Preview and import Apple Card transaction CSV exports from Wallet."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from datetime import datetime
from decimal import Decimal, InvalidOperation

from backend.bank_sync import purchase_suggestion
from backend.ledger import ValidationError

MAX_CSV_BYTES = 2_000_000


def _header(value):
    return re.sub(r'[^a-z0-9]', '', (value or '').lstrip('\ufeff').lower())


def _date(value):
    raw=(value or '').strip()
    for fmt in ('%m/%d/%Y','%m/%d/%y','%Y-%m-%d'):
        try:return datetime.strptime(raw,fmt).date().isoformat()
        except ValueError:pass
    raise ValidationError(f'Apple CSV has an invalid transaction date: {raw or "blank"}.')


def _cents(value):
    raw=(value or '').strip().replace('$','').replace(',','')
    negative=raw.startswith('(') and raw.endswith(')')
    if negative:raw=raw[1:-1]
    try:amount=Decimal(raw)
    except InvalidOperation:raise ValidationError(f'Apple CSV has an invalid amount: {value or "blank"}.') from None
    if amount.as_tuple().exponent < -2:raise ValidationError('Apple CSV amounts must use no more than two decimal places.')
    result=int(amount*100)*(-1 if negative else 1)
    if abs(result)>10**12:raise ValidationError('Apple CSV amount is too large.')
    return result


def _kind(row):
    kind=(row.get('type') or '').strip().lower()
    words=' '.join((kind,row.get('description',''),row.get('merchant',''))).lower()
    if 'payment' in kind:return 'payment'
    if 'refund' in kind:return 'refund'
    if 'daily cash' in words or 'adjustment' in kind or 'interest charge' in words:return 'adjustment'
    if kind in ('credit','return'):return 'refund'
    return 'purchase'


def _category(row):
    apple=(row.get('category') or '').strip().lower()
    direct={'food & drink':'Food','restaurants':'Food','groceries':'Grocery','grocery':'Grocery',
            'travel':'Travel','transportation':'Travel','shopping':'Shopping','entertainment':'Shopping',
            'education':'Tuition','services':'Subscriptions'}
    if apple in direct:return direct[apple]
    return purchase_suggestion({'merchant_name':row.get('merchant'),'name':row.get('description'),
                                'personal_finance_category':{'primary':apple}})['category']


def _existing_match(ledger, account_id, item):
    expected=item['amount_cents'] if item['kind']=='purchase' else -item['amount_cents']
    needle=re.sub(r'[^a-z0-9]','',item['description'].lower())
    for event in ledger.snapshot()['transactions']:
        if event['date']!=item['date'] or event['effects']['accounts'].get(account_id)!=expected:continue
        existing=re.sub(r'[^a-z0-9]','',event['description'].lower())
        if not needle or not existing or needle in existing or existing in needle:return event['id']
    return None


def _table(ledger):
    ledger.db.execute('CREATE TABLE IF NOT EXISTS apple_card_imports (fingerprint TEXT PRIMARY KEY,event_id TEXT NOT NULL,imported_at TEXT NOT NULL)')


def parse(text):
    if not isinstance(text,str) or not text.strip():raise ValidationError('Choose an Apple Card transaction CSV.')
    if len(text.encode('utf-8'))>MAX_CSV_BYTES:raise ValidationError('Apple Card CSV must be smaller than 2 MB.')
    try:reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    except csv.Error as exc:raise ValidationError('Apple Card CSV could not be read.') from exc
    if not reader.fieldnames:raise ValidationError('Apple Card CSV has no header row.')
    names={_header(name):name for name in reader.fieldnames}
    aliases={'date':('transactiondate','date'),'description':('description','transactiondescription'),
             'merchant':('merchant','merchantname'),'category':('category',),'type':('type','transactiontype'),
             'amount':('amountusd','amount')}
    chosen={key:next((names[name] for name in options if name in names),None) for key,options in aliases.items()}
    if not chosen['date'] or not chosen['description'] or not chosen['amount']:
        raise ValidationError('Use the transaction CSV exported by Wallet. It needs Transaction Date, Description and Amount (USD).')
    rows=[];occurrences={}
    try:
        for source in reader:
            if not any((value or '').strip() for value in source.values()):continue
            row={key:(source.get(column,'') if column else '') for key,column in chosen.items()}
            signed=_cents(row['amount']);kind=_kind(row)
            if signed==0:continue
            # Wallet normally exports purchases as positive and credits/payments as negative.
            # The Type column is authoritative; magnitude is used in Basih events.
            amount=abs(signed);description=(row['merchant'] or row['description']).strip() or 'Apple Card transaction'
            category=_category(row)
            basis=json.dumps([_date(row['date']),row['description'].strip(),row['merchant'].strip(),row['category'].strip(),row['type'].strip(),signed],separators=(',',':'))
            occurrence=occurrences.get(basis,0)+1;occurrences[basis]=occurrence
            fingerprint=hashlib.sha256(f'{basis}\n{occurrence}'.encode()).hexdigest()
            rows.append({'fingerprint':fingerprint,'date':_date(row['date']),'description':description,
                         'raw_description':row['description'].strip(),'kind':kind,'category':category,
                         'amount_cents':amount,'source_amount_cents':signed})
    except csv.Error as exc:raise ValidationError('Apple Card CSV contains a malformed row.') from exc
    if not rows:raise ValidationError('Apple Card CSV contains no transactions.')
    return rows


def preview(ledger,text,account_id):
    account=ledger.accounts().get(account_id)
    if not account or account['kind']!='card':raise ValidationError('Choose the Apple Card account.')
    _table(ledger)
    imported={row[0]:row[1] for row in ledger.db.execute('SELECT fingerprint,event_id FROM apple_card_imports')}
    result=[]
    for item in parse(text):
        if item['category'] not in ledger.spending_categories():item['category']=ledger.spending_categories()[0]
        prior=imported.get(item['fingerprint']);existing=prior or _existing_match(ledger,account_id,item)
        error=None
        if item['kind']=='payment' and (not account.get('default_payment_account') or not account.get('payment_code')):
            error='Link this card to its payment bank in Banks & cards first.'
        result.append(item|{'duplicate':bool(existing),'existing_event_id':existing,'error':error})
    return {'account_id':account_id,'rows':result,'new_count':sum(not r['duplicate'] and not r['error'] for r in result)}


def commit(ledger,text,account_id,fingerprints):
    report=preview(ledger,text,account_id);selected=set(fingerprints or [])
    if not selected:raise ValidationError('Choose at least one new Apple Card transaction.')
    account=ledger.accounts()[account_id];created=skipped=0
    available={row['fingerprint']:row for row in report['rows']}
    if not selected.issubset(available):raise ValidationError('The Apple CSV preview changed. Preview it again.')
    with ledger.db:
        for fingerprint in selected:
            row=available[fingerprint]
            if row['duplicate'] or row['error']:
                skipped+=1;continue
            base={'date':row['date'],'date_precision':'day','description':row['description'],
                  'amount_cents':row['amount_cents'],'status':'posted'}
            if row['kind']=='purchase':
                event=base|{'kind':'purchase','category':row['category'],'personal_cents':row['amount_cents'],
                            'payer':{'type':'account','id':account_id},'shares':[]}
            elif row['kind']=='refund':
                event=base|{'kind':'refund','category':row['category'],'personal_cents':row['amount_cents'],'account_id':account_id}
            elif row['kind']=='payment':
                event=base|{'kind':'card_payment','category':account['payment_code'],'account_id':account_id,
                            'payment_bank_id':account['default_payment_account']}
            else:
                event=base|{'kind':'balance_adjustment','account_id':account_id,'direction':'received'}
            event_id=ledger.save_event(event)
            ledger.db.execute("INSERT INTO apple_card_imports VALUES(?,?,datetime('now'))",(fingerprint,event_id));created+=1
    return {'imported':created,'skipped':skipped}
