#!/bin/zsh
# Double-click setup for the clean, self-contained Mac app.
set -e

setup_dir="${0:A:h}"
source_app="$setup_dir/Basih.app"
target_app="$HOME/Desktop/Basih.app"

if [[ ! -d "$source_app" ]]; then
  /usr/bin/osascript -e 'display alert "Basih setup" message "Keep Install Basih.command beside Basih.app, then double-click it again." as critical'
  exit 1
fi

if ! /usr/bin/codesign --verify --deep --strict "$source_app" >/dev/null 2>&1; then
  /usr/bin/osascript -e 'display alert "Basih setup" message "This app copy is incomplete or damaged. Download a fresh Basih ZIP and try again." as critical'
  exit 1
fi

previous_app=""
if [[ -e "$target_app" ]]; then
  # Quit the Desktop copy before moving its bundle. The ledger and bank
  # connection live in Application Support and are never moved here.
  /usr/bin/osascript -e 'tell application id "local.basih.finance.shared" to quit' >/dev/null 2>&1 || true
  for attempt in {1..30}; do
    if ! /usr/bin/pgrep -f "$target_app/Contents/MacOS/Basih" >/dev/null 2>&1; then break; fi
    /bin/sleep 1
  done
  if /usr/bin/pgrep -f "$target_app/Contents/MacOS/Basih" >/dev/null 2>&1; then
    /usr/bin/osascript -e 'display alert "Close Basih first" message "Quit the Desktop Basih app, then double-click the installer again."'
    exit 1
  fi
  previous_app="$HOME/Desktop/.Basih-previous-$$.app"
  /bin/mv "$target_app" "$previous_app"
fi

if ! /usr/bin/ditto "$source_app" "$target_app" || ! /usr/bin/codesign --verify --deep --strict "$target_app" >/dev/null 2>&1; then
  if [[ -n "$previous_app" && -d "$previous_app" ]]; then
    /bin/rm -rf "$target_app"
    /bin/mv "$previous_app" "$target_app"
  fi
  /usr/bin/osascript -e 'display alert "Basih update failed" message "The previous app was restored. Your data was not changed." as critical'
  exit 1
fi

if [[ -n "$previous_app" && -d "$previous_app" ]]; then /bin/rm -rf "$previous_app"; fi
if [[ "${BASIH_INSTALL_NO_OPEN:-0}" == "1" ]]; then exit 0; fi
if ! /usr/bin/open "$target_app"; then
  /usr/bin/osascript -e 'display alert "Basih was copied to your Desktop" message "macOS did not open it yet. In Finder, Control-click Basih.app on your Desktop and choose Open."'
  exit 1
fi

/usr/bin/osascript -e 'display notification "Basih is ready on your Desktop" with title "Basih setup"'
