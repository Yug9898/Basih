"""Suggestions only: no financial writes, no inferred balancing entries."""
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation


def cents(value):
    if value is None or isinstance(value, bool): return None
    try:
        number = Decimal(str(value)) * 100
        if not number.is_finite() or number != number.to_integral_value(): return None
        return int(number)
    except (InvalidOperation, ValueError): return None


def nearby(bank_date, entry):
    try:
        posted = date.fromisoformat(bank_date)
        start = date.fromisoformat(entry['date'])
        end = start + timedelta(days=6 if entry.get('date_precision') == 'week' else 0)
        return start - timedelta(days=3) <= posted <= end + timedelta(days=3)
    except (ValueError, TypeError, KeyError): return False


def compare(snapshot, accounts, transactions, mapping, links=None, resolved=None):
    links=links or {}
    resolved=resolved or set()
    sources = {a['account_id']: a for a in accounts}
    targets = {a['id']: a for a in snapshot['accounts']}
    balances = []
    for target, ledger in targets.items():
        ids = [key for key, value in mapping.items() if value == target]
        if not ids: continue
        values = [cents(sources.get(key, {}).get('balances', {}).get('current')) for key in ids]
        complete = all(v is not None and sources.get(key, {}).get('balances', {}).get('iso_currency_code') == 'USD' for key, v in zip(ids, values))
        # User's B2 is College Checking + Savings. One source is incomplete.
        complete = complete and (target != 'B2' or len(ids) >= 2)
        bank = sum(values) if complete else None
        local = ledger.get('posted_balance_cents')
        if ledger['kind'] == 'card':
            bank = -bank if bank is not None else None
            local = -local if local is not None else None
        pending = [t for t in transactions if t.get('account_id') in ids and t.get('pending') and t.get('iso_currency_code') == 'USD']
        pending_delta = -sum(cents(t.get('amount')) or 0 for t in pending)
        unreviewed = [t for t in transactions if t.get('account_id') in ids and t.get('transaction_id') not in links
                      and t.get('iso_currency_code') == 'USD' and cents(t.get('amount')) is not None]
        awaiting = [t for t in unreviewed if t.get('transaction_id') not in resolved]
        unreviewed_delta = -sum(cents(t.get('amount')) for t in unreviewed)
        expected = bank + pending_delta if bank is not None else None
        candidate = local + unreviewed_delta if local is not None else None
        # A manually entered but not-yet-linked row may already be in `local`.
        # Apply the staged movements only when they improve reconciliation.
        apply_unreviewed = expected is not None and local is not None and candidate is not None and abs(expected-candidate) < abs(expected-local)
        after_bank = candidate if apply_unreviewed else local
        applied_unreviewed = unreviewed_delta if apply_unreviewed else 0
        balances.append({'id': target, 'name': ledger['name'], 'sources': ids, 'complete': complete,
                         'bank_cents': bank, 'ledger_cents': local,
                         'ledger_after_bank_cents': after_bank,
                         'unreviewed_cents': applied_unreviewed, 'unreviewed_count': len(awaiting) if apply_unreviewed else 0,
                         'pending_cents': pending_delta, 'pending_count': len(pending),
                         'after_pending_cents': bank + pending_delta if bank is not None else None,
                         'difference_cents': bank + pending_delta-after_bank if bank is not None and after_bank is not None else None,
                         'fetched_at': [sources.get(key, {}).get('fetched_at') for key in ids]})
    # Treat each account effect as a separate leg. A CP entry can match its
    # bank withdrawal and card credit, but two withdrawals cannot claim one leg.
    legs = []
    for entry in snapshot['transactions']:
        if entry.get('status') != 'posted' or entry.get('kind') == 'balance_adjustment': continue
        for target, delta in entry['effects']['accounts'].items():
            if target not in mapping.values() or not delta: continue
            legs.append({'id': entry['id'], 'account': target, 'entry': entry,
                         'amount': -delta if targets[target]['kind'] == 'card' else delta})
    linked_legs={(link.get('event_id'),link.get('account')) for link in links.values()}
    rows = []; claims = {}
    for t in transactions:
        target = mapping.get(t.get('account_id'))
        value = cents(t.get('amount'))
        amount = -value if value is not None else None
        eligible = target in targets and t.get('iso_currency_code') == 'USD' and amount is not None
        candidates = [i for i, leg in enumerate(legs) if eligible and t['transaction_id'] not in links and (leg['id'],leg['account']) not in linked_legs and leg['account'] == target and leg['amount'] == amount and nearby(t.get('date'), leg['entry'])]
        for i in candidates: claims[i] = claims.get(i, 0) + 1
        rows.append({'transaction_id': t['transaction_id'], 'name': t.get('name', ''), 'date': t.get('date'),
                     'source_account': t.get('account_id'), 'account': target, 'amount_cents': amount,
                     'status': 'pending' if t.get('pending') else 'unmapped' if not target else 'unsupported' if not eligible else 'no_match',
                     'candidate_indices': candidates})
    used = {i for i,leg in enumerate(legs) if (leg['id'],leg['account']) in linked_legs}
    for row in rows:
        indices = row.pop('candidate_indices')
        row['candidates'] = [{'id': legs[i]['id'], 'description': legs[i]['entry'].get('description', ''),
                              'category': legs[i]['entry'].get('category'), 'date': legs[i]['entry']['date']} for i in indices]
        if indices:
            row['status'] = 'possible_match' if len(indices) == 1 and claims[indices[0]] == 1 else 'ambiguous'
            if row['status'] == 'possible_match': used.add(indices[0])
    # Opposite legs between two sources mapped to the same bank are candidates
    # for an internal transfer, not verified transfers and never new spending.
    for row in rows:
        if row['status'] != 'no_match' or targets.get(row['account'], {}).get('kind') != 'bank': continue
        other = [r for r in rows if r['status'] == 'no_match' and r['account'] == row['account']
                 and r['source_account'] != row['source_account'] and r['amount_cents'] == -row['amount_cents']
                 and nearby(r['date'], {'date': row['date']})]
        if len(other) == 1:
            row['internal_transfer_candidate'] = other[0]['transaction_id']
    unmatched = []
    for i, leg in enumerate(legs):
        if i in used: continue
        dates = sorted(t['date'] for t in transactions if mapping.get(t.get('account_id')) == leg['account'] and not t.get('pending') and t.get('date'))
        entry = leg['entry']
        within = bool(dates and dates[0] <= entry['date'] <= dates[-1])
        unmatched.append({'id': leg['id'], 'account': leg['account'], 'date': entry['date'],
                          'description': entry.get('description', ''), 'category': entry.get('category'),
                          'amount_cents': leg['amount'], 'status': 'ambiguous' if claims.get(i) else 'not_found' if within else 'outside_downloaded_dates'})
    return {'balances': balances, 'transactions': rows, 'manual_unmatched': unmatched}
