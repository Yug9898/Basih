"""Local, previewed Notes table imports. Never evaluates spreadsheet formulas."""
import csv, hashlib, io, json, re, sqlite3
from datetime import date,timedelta,datetime,timezone
from uuid import uuid4
from backend.ledger import ValidationError,CARD_PAYMENTS
from backend.history import history_snapshot,exact_cents

def amount(text, optional=False):
    value=str(text).strip().replace('$','').replace(',','')
    if not value and optional:return None
    if not re.fullmatch(r'-?\d+(\.\d{1,2})?',value):raise ValidationError('Enter money with at most two decimal places.')
    negative=value.startswith('-');value=value.lstrip('-')
    whole,_,fraction=value.partition('.')
    result=int(whole)*100+int(fraction.ljust(2,'0') or '0')
    if result>10**12:raise ValidationError('Amount is too large.')
    return -result if negative else result

def parse(text):
    if not isinstance(text,str) or not text.strip() or len(text)>40000:raise ValidationError('Paste a table up to 40,000 characters.')
    lines=list(csv.reader(io.StringIO(text),delimiter='\t' if '\t' in text else ','))
    rows=[]
    for line in lines:
        if not any(c.strip() for c in line):continue
        if len(line)==1 and not rows:continue
        if len(line)!=5:raise ValidationError('Use five columns: Amount, Debit, Description, Account, Category. Copy the whole table or paste CSV.')
        if line[0].strip().lower() in ('amount','amount ($)'):continue
        line=[c.strip() for c in line];line[3]=line[3].upper();rows.append(line)
    if not rows or len(rows)>150:raise ValidationError('Paste between 1 and 150 transaction rows.')
    return rows

def normalize(row):
    return [('subscriptions' if str(v).strip().casefold()=='subscription' else str(v).strip().casefold()) for v in row]

def fingerprint(row,week):
    return hashlib.sha256(json.dumps([normalize(row),week]).encode()).hexdigest()

def preview(ledger,text,week):
    chosen=date.fromisoformat(week);week=chosen.isoformat()
    rows=parse(text); archive=history_snapshot(ledger); existing=[]
    if archive:
        for r in archive['transactions']:
            v=r['values'];existing.append(([v[1],v[2],v[3],v[4],v[5]],r['week_start'],'week'))
    for e in ledger.snapshot()['transactions']:
        if e['kind']=='historical':continue
        debit=-e['amount_cents'] if e['kind']=='repayment' and e.get('direction')=='received' else sum(s['amount_cents'] for s in e.get('shares',[])) or None
        existing.append(([e['amount_cents']/100 if e['kind']!='repayment' else None,debit/100 if debit is not None else None,e['description'],e.get('payer',{}).get('id',e.get('account_id')),e.get('category','Debited' if e['kind']=='repayment' else e['kind'])],e['date'],e.get('date_precision','day')))
    def key(row):
        try:return [(None if v is None else exact_cents(v) if type(v) in (int,float) else amount(v,True)) for v in row[:2]]+normalize(row[2:])
        except ValidationError:return None
    keys={(json.dumps(key(r)),w,(date.fromisoformat(w)+timedelta(days=6 if precision=='week' else 0)).isoformat()) for r,w,precision in existing if w}
    if ledger.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='notes_rows'").fetchone():
        keys.update((r['row_key'],r['entry_date'],r['entry_date']) for r in ledger.db.execute('SELECT * FROM notes_rows'))
    result=[]; consumed=set();seen=set()
    for i,row in enumerate(rows):
        item={'index':i,'input':row,'duplicate':False,'error':None,'paired_with':None,'needs_person':False}
        if i in consumed:
            item['paired_with']=i-1;result.append(item);continue
        try:
            total=amount(row[0],True);debit=amount(row[1],True);category=row[4].casefold()
            if row[3] not in ledger.accounts():raise ValidationError('Choose a known account code.')
            if not row[2]:raise ValidationError('Description is required.')
            item['duplicate']=any(k==json.dumps(key(row)) and first<=week<=last for k,first,last in keys) or json.dumps(key(row)) in seen
            seen.add(json.dumps(key(row)))
            if category=='transfer' and total and i+1<len(rows):
                following=rows[i+1]
                if following[4].casefold()=='deposit' and amount(following[0],True)==total and following[3]!=row[3] and amount(following[1],True) is None:
                    item['destination']=following[3];consumed.add(i+1)
            item['needs_person']=debit is not None and debit!=0 or category=='debited'
            draft(ledger,row,week,{'person_id':next(iter(ledger.people()),None),'destination_account_id':item.get('destination')})
        except (ValidationError,ValueError) as e:item['error']=str(e)
        result.append(item)
    return {'date':week,'rows':result}

def draft(ledger,row,week,config):
    total=amount(row[0],True);debit=amount(row[1],True);description,account,category=row[2:]
    base={'date':week,'date_precision':'day','status':'posted','description':description}
    person=config.get('person_id');events=[]
    if total is not None:
        if total<=0:raise ValidationError('Amount must be positive; receipts belong in negative Debit.')
        c=category.casefold()
        if c=='deposit':event=base|{'kind':'deposit','account_id':account,'amount_cents':total,'category':'Deposit'}
        elif c=='transfer':
            dest=config.get('destination_account_id')
            if not dest:raise ValidationError('Select a destination bank for the transfer.')
            event=base|{'kind':'transfer','account_id':account,'destination_account_id':dest,'amount_cents':total,'category':'Transfer'}
        elif c.upper() in [a['payment_code'] for a in ledger.accounts().values()]:event=base|{'kind':'card_payment','category':c.upper(),'account_id':account,'amount_cents':total}
        else:
            actual=next((name for name in ledger.spending_categories() if name.casefold()==category.casefold() or name=='Subscriptions' and category.casefold()=='subscription'),None)
            if c=='debited':actual='Other'
            if not actual:raise ValidationError('Unsupported category. Use a spending category, Deposit, Transfer, Debited or CP1–CP3.')
            share=total if c=='debited' else debit if debit is not None and debit>0 else 0
            event=base|{'kind':'purchase','amount_cents':total,'category':actual,'personal_cents':total-share,'payer':{'type':'account','id':account},'shares':[{'person_id':person,'amount_cents':share}] if share else []}
        events.append(ledger.validate(event))
    if debit is not None and debit<0:
        events.append(ledger.validate(base|{'kind':'repayment','amount_cents':-debit,'account_id':account,'person_id':person,'direction':'received'}))
    if not events:raise ValidationError('Enter an Amount or a negative Debit receipt.')
    return events

def commit(ledger,text,week,selections,batch_id):
    if not isinstance(batch_id,str) or not re.fullmatch(r'[a-zA-Z0-9-]{16,80}',batch_id):raise ValidationError('Invalid import identifier.')
    if not isinstance(selections,list) or not selections:raise ValidationError('Select at least one row.')
    report=preview(ledger,text,week); rows=report['rows'];week=report['date']
    request_hash=hashlib.sha256(json.dumps([text,week,selections],sort_keys=True).encode()).hexdigest()
    ledger.db.execute('CREATE TABLE IF NOT EXISTS notes_rows (batch_id TEXT NOT NULL, row_index INTEGER NOT NULL, row_key TEXT NOT NULL, entry_date TEXT NOT NULL, PRIMARY KEY(batch_id,row_index))')
    ledger.db.execute('CREATE TABLE IF NOT EXISTS notes_batches (id TEXT PRIMARY KEY, request_hash TEXT NOT NULL, result TEXT NOT NULL)')
    previous=ledger.db.execute('SELECT * FROM notes_batches WHERE id=?',(batch_id,)).fetchone()
    if previous:
        if previous['request_hash']!=request_hash:raise ValidationError('Import request changed. Preview it again.')
        return json.loads(previous['result'])
    events=[];selected=set()
    for config in selections:
        if not isinstance(config,dict) or type(config.get('index')) is not int:raise ValidationError('Invalid selected row.')
        i=config['index']
        if i in selected or not 0<=i<len(rows):raise ValidationError('Invalid or repeated selected row.')
        selected.add(i);item=rows[i]
        if item['paired_with'] is not None:raise ValidationError('The paired transfer receipt is included with its transfer.')
        if item['duplicate'] and config.get('allow_duplicate') is not True:raise ValidationError('A matching entry exists. Explicitly confirm duplicates before importing.')
        merged={'destination_account_id':item.get('destination')}|config
        events.extend(draft(ledger,item['input'],week,merged))
    # Validate the whole batch before any posting; one transaction also protects retries.
    now=datetime.now(timezone.utc).isoformat(timespec='microseconds')
    result={'ids':[str(uuid4()) for _ in events],'rows':len(selected),'events':len(events)}
    with ledger.db:
        for event_id,event in zip(result['ids'],events):
            payload=json.dumps(event,sort_keys=True)
            ledger.db.execute('INSERT INTO events(id,entered_at,revision,payload) VALUES(?,?,1,?)',(event_id,now,payload))
            ledger.db.execute('INSERT INTO revisions VALUES(?,1,?,?)',(event_id,now,payload))
        for i in selected:
            row=rows[i]['input'];row_key=json.dumps([amount(row[0],True),amount(row[1],True),*normalize(row[2:])])
            ledger.db.execute('INSERT INTO notes_rows VALUES(?,?,?,?)',(batch_id,i,row_key,week))
        ledger.db.execute('INSERT INTO notes_batches VALUES(?,?,?)',(batch_id,request_hash,json.dumps(result)))
    return result
