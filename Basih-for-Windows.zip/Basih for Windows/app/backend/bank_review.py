"""Explicit review actions; event and provider association commit atomically."""
import json
import hashlib
from datetime import datetime, timezone
from uuid import uuid4
from backend.ledger import ValidationError, effects
from backend.bank_compare import cents, nearby

def fingerprint(transaction):
    return hashlib.sha256(json.dumps(transaction,sort_keys=True).encode()).hexdigest()

def review(bank, data):
    if not bank.writable: raise ValidationError('This bank connection is preview-only.')
    tid = data.get('transaction_id')
    t = bank.get('transactions', {}).get(tid)
    if not t: raise ValidationError('Bank transaction no longer available. Sync and review again.')
    if not bank.in_scope(t):raise ValidationError('Bank entry is outside this ledger’s import period.')
    if data.get('fingerprint') != fingerprint(t): raise ValidationError('Bank transaction changed. Reload before approving.')
    target = bank.get('mapping', {}).get(t.get('account_id'))
    accounts = bank.ledger.accounts()
    if target not in accounts or t.get('iso_currency_code') != 'USD': raise ValidationError('Map this USD account before reviewing.')
    amount = cents(t.get('amount'))
    if amount is None: raise ValidationError('Unsupported bank amount.')
    delta = amount if accounts[target]['kind'] == 'card' else -amount
    links = bank.get('links', {})
    if tid in links: raise ValidationError('This bank transaction was already reviewed. Edit its existing ledger entry instead.')
    snapshot = bank.ledger.snapshot()
    event_id = data.get('event_id')
    if event_id:
        entry = next((e for e in snapshot['transactions'] if e['id'] == event_id),None)
        if not entry or entry.get('status') != 'posted' or entry['effects']['accounts'].get(target) != delta or not nearby(t.get('date'),entry):
            raise ValidationError('This entry does not match the bank account, amount and date.')
        if any(link.get('event_id') == event_id and link.get('account') == target for link in links.values()):
            raise ValidationError('Another bank transaction already links to this entry’s account movement.')
    else:
        possible = [e for e in snapshot['transactions'] if e.get('status')=='posted' and e['effects']['accounts'].get(target)==delta and nearby(t.get('date'),e)]
        if possible: raise ValidationError('A matching manual entry exists. Link it instead of adding a duplicate.')
        event = data.get('event')
        if not isinstance(event,dict) or event.get('date') != t.get('date') or event.get('status')!='posted':
            raise ValidationError('Use the bank transaction date and deducted status.')
        event = bank.ledger.validate(event)
        impact = effects(event, accounts, bank.ledger.people(), bank.ledger.spending_categories())
        if impact['accounts'].get(target) != delta:
            raise ValidationError('Entry amount and account must match the bank movement.')
        if event.get('kind') not in ('purchase','refund','deposit','repayment','card_payment','transfer'):
            raise ValidationError('Choose a supported bank entry type.')
        event_id = str(uuid4())
    links[tid] = {'event_id':event_id,'account':target,'fingerprint':fingerprint(t),'automatic':data.get('automatic') is True}
    with bank.db:
        if not data.get('event_id'):
            now = datetime.now(timezone.utc).isoformat()
            payload = json.dumps(event,sort_keys=True)
            bank.db.execute('INSERT INTO events(id,entered_at,revision,payload) VALUES(?,?,?,?)',(event_id,now,1,payload))
            bank.db.execute('INSERT INTO revisions VALUES(?,?,?,?)',(event_id,1,now,payload))
            if event['kind']=='purchase':
                rules=bank.get('merchant_rules',{})
                rules[t.get('merchant_name') or t.get('name','')]={'description':event['description'],'category':event['category']}
                bank.put('merchant_rules',rules)
        bank.put('links',links)
    return bank.status()
