"""Isolated Plaid environments and read-only ledger comparison."""
import hashlib
import json
import os
import re
import ssl
from pathlib import Path
import subprocess
import sys
import threading
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from uuid import uuid4
from datetime import date, datetime, timezone
from backend.ledger import ValidationError
from backend.bank_scope import START_DATE,in_scope
from backend.history import has_history

LOCK = threading.RLock()
CATEGORIES = ('Food','Grocery','Rent','Tuition','Travel','Shopping','Other','Subscriptions')

def institution_brand(value):
    name=(value or '').lower()
    if 'wells fargo' in name:return 'wells_fargo'
    if 'american express' in name or 'amex' in name:return 'american_express'
    if 'discover' in name:return 'discover'
    if 'pnc' in name:return 'pnc'
    if 'chase' in name:return 'chase'
    if 'apple' in name:return 'apple'
    return None

def purchase_suggestion(transaction, rules=None):
    """Return a friendly description and best local category for a Plaid purchase."""
    merchant=(transaction.get('merchant_name') or '').strip();raw_name=(transaction.get('name') or '').strip()
    rule=(rules or {}).get(merchant) or (rules or {}).get(raw_name) or {}
    if rule.get('category') in CATEGORIES:return {'description':rule.get('description') or merchant or raw_name,'category':rule['category']}
    finance=transaction.get('personal_finance_category') or {}
    combined=' '.join((merchant,raw_name,str(finance.get('primary') or ''),str(finance.get('detailed') or ''))).upper()
    groups=(
        ('Grocery',('GROCERY','SUPERMARKET','WALMART','TARGET','COSTCO','WHOLE FOODS','TRADER JOE','ALDI')),
        ('Food',('FOOD_AND_DRINK','RESTAURANT','CAFE','COFFEE','PIZZA','DOORDASH','UBER EATS','GRUBHUB','MCDONALD','CHIPOTLE','DOMINO')),
        ('Travel',('TRAVEL','AIRLINE','FLIGHT','HOTEL','LODGING','UBER','LYFT','TAXI','PARKING','TRANSIT','GAS STATION')),
        ('Rent',('RENT','LEASE')),('Tuition',('TUITION','UNIVERSITY','COLLEGE','EDUCATION')),
        ('Subscriptions',('SUBSCRIPTION','STREAMING','NETFLIX','SPOTIFY','HULU','APPLE.COM/BILL','GOOGLE ONE','ADOBE','MEMBERSHIP')),
        ('Shopping',('GENERAL_MERCHANDISE','CLOTHING','ELECTRONICS','DEPARTMENT STORE','AMAZON','SHOPPING')))
    category=next((name for name,terms in groups if any(term in combined for term in terms)),'Other')
    return {'description':merchant or re.sub(r'\s{2,}',' ',raw_name).strip() or 'Purchase','category':category}


def tls_context():
    context = ssl.create_default_context()
    # Framework Python's default CA path may not exist on a user's Mac.
    # Load macOS's maintained PEM trust bundle without disabling TLS checks.
    system_bundle = Path('/etc/ssl/cert.pem')
    if sys.platform == 'darwin' and system_bundle.is_file():
        context.load_verify_locations(cafile=str(system_bundle))
    return context


def vault(action, account, value=None):
    if sys.platform == 'win32':
        helper = Path(__file__).resolve().parents[1] / 'desktop/windows_secret.ps1'
        if not helper.exists(): raise ValidationError('Windows credential helper is missing. Reinstall Basih.')
        result = subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(helper),action,account],
                                input=value or '', text=True, capture_output=True, timeout=60)
        if result.returncode == 3 and action == 'get': return None
        if result.returncode: raise ValidationError('Windows could not access this user’s protected credentials.')
        return result.stdout if action == 'get' else None
    helper = (Path(sys.executable).resolve().parent.parent / 'keychain-helper'
              if getattr(sys, 'frozen', False) else Path(__file__).resolve().parents[1] / '.tools/keychain-helper')
    if not helper.exists():
        raise ValidationError('Keychain helper is missing. Rebuild Basih.')
    try:
        result = subprocess.run([str(helper)], input=json.dumps(dict(action=action, account=account, value=value)),
                                text=True, capture_output=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired):
        raise ValidationError('macOS Keychain did not respond. Try again.') from None
    if result.returncode == 3 and action == 'get': return None
    if result.returncode:
        match = re.search(r'Keychain status: (-?\d+)', result.stderr)
        code = match.group(1) if match else None
        if code == '-25308':
            raise ValidationError('macOS Keychain is locked or cannot show its access prompt. Unlock your login keychain in Keychain Access, then retry.')
        if code in ('-128', '-25293'):
            raise ValidationError('Keychain permission was cancelled or denied. Retry and allow Basih access when macOS asks.')
        detail = 'macOS status ' + code if code else 'helper exit ' + str(result.returncode)
        raise ValidationError('Basih could not access Keychain (' + detail + '). Restart the updated Basih app and retry.')
    return result.stdout if action == 'get' else None


class BankSync:
    def __init__(self, ledger, storage=vault, transport=None, environment=None):
        self.ledger, self.db, self.storage = ledger, ledger.db, storage
        self.transport = transport
        saved = self.db.execute("SELECT value FROM meta WHERE key='bank_environment'").fetchone()
        profile = self.db.execute("SELECT value FROM meta WHERE key='profile_name'").fetchone()
        edition = os.environ.get('BASIH_EDITION')
        default_environment = 'sandbox' if edition == 'test' else 'production' if edition == 'shared' or (profile and not has_history(ledger)) else 'sandbox'
        self.environment = environment or (saved[0] if saved else default_environment)
        if self.environment not in ('sandbox', 'production'): raise ValidationError('Choose Sandbox or Production.')
        self.table = 'bank_stage' if self.environment == 'sandbox' else 'bank_stage_production'
        self.db.execute(f'CREATE TABLE IF NOT EXISTS {self.table} (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
        self.db.commit()
        if not self.get('namespace'):
            self.put('namespace', 'basih-plus:' + str(uuid4())); self.db.commit()
        self.namespace = self.get('namespace')
        self.test_mode = edition == 'test'
        self.writable = self.environment == 'production' or self.test_mode
        self.new_user_setup = not has_history(ledger) and (bool(profile) or edition in ('test','shared'))
        selected_start = self.db.execute("SELECT value FROM meta WHERE key='bank_import_start_date'").fetchone()
        self.scope_start = START_DATE if has_history(ledger) else selected_start[0] if selected_start else '0001-01-01'
        if self.environment == 'production' and has_history(ledger) and self.get('auto_import_seen') is None:
            # Existing downloads predate automatic entry creation; never backfill them.
            self.put('auto_import_seen', sorted(self.get('transactions', {}).keys()))
            self.put('auto_import_start', datetime.now().date().isoformat())
            self.db.commit()

    def in_scope(self, entry, manual=False):
        return in_scope(entry, manual=manual, start_date=self.scope_start)

    def get(self, key, default=None):
        row = self.db.execute(f'SELECT value FROM {self.table} WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def put(self, key, value):
        self.db.execute(f'INSERT OR REPLACE INTO {self.table} VALUES (?,?)', (key, json.dumps(value)))

    def secret(self, key, value=None):
        return self.storage('get' if value is None else 'set', self.namespace + ':' + key, value)

    def call(self, endpoint, data):
        credentials = self.secret('credentials')
        if not credentials: raise ValidationError(f'Save your {self.environment.title()} credentials first.')
        payload = json.loads(credentials) | data
        if self.transport: return self.transport(endpoint, payload)
        request = Request(f'https://{self.environment}.plaid.com' + endpoint,
                          data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'}, method='POST')
        try:
            with urlopen(request, timeout=30, context=tls_context()) as response: return json.load(response)
        except HTTPError as error:
            try: code = json.load(error).get('error_code', 'REQUEST_FAILED')
            except (ValueError, OSError): code = 'REQUEST_FAILED'
            # Never relay provider payloads or credentials to browser/logs.
            if not isinstance(code, str) or not code.replace('_', '').isalnum(): code = 'REQUEST_FAILED'
            raise ValidationError('Plaid: ' + code[:80]) from None
        except (URLError, TimeoutError, OSError) as error:
            reason = error.reason if isinstance(error, URLError) else error
            if isinstance(reason, ssl.SSLCertVerificationError):
                raise ValidationError('Plaid HTTPS certificate could not be verified. Update macOS or check your network certificate settings; no ledger entries were changed.') from None
            raise ValidationError('Could not reach Plaid. Try again; no ledger entries were changed.') from None

    def status(self):
        from backend.bank_compare import compare
        from backend.bank_review import fingerprint
        snapshot = self.ledger.snapshot()
        snapshot = snapshot | {'transactions':[e for e in snapshot['transactions'] if self.in_scope(e,manual=True)]}
        rules=self.get('merchant_rules', {})
        raw_visible = {key:t for key,t in self.get('transactions',{}).items() if self.in_scope(t)}
        visible = {key:(t | {'suggestion':purchase_suggestion(t,rules)}) for key,t in raw_visible.items()}
        return {'environment': self.environment, 'test_mode': self.test_mode, 'writable': self.writable,
                'configured': self.get('configured', False),
                'pending_link': bool(self.get('link')), 'items': self.get('items', []),
                'accounts': self.get('accounts', []), 'transactions': list(visible.values()),
                'start_date': None if self.scope_start == '0001-01-01' else self.scope_start,
                'last_sync': self.get('last_sync'), 'mapping': self.get('mapping', {}),
                'links': self.get('links', {}), 'resolved': self.get('resolved', {}), 'merchant_rules': rules,
                # Suggestions are Basih metadata, not provider data. Fingerprints
                # must remain stable when the classifier improves.
                'fingerprints': {key:fingerprint(t) for key,t in raw_visible.items()},
                'ledger_accounts': [{'id': a['id'], 'name': a['name'], 'kind': a['kind']} for a in snapshot['accounts']],
                'manual_entries': [{'id':e['id'],'date':e['date'],'description':e['description'],'category':e.get('category'),'accounts':e['effects']['accounts']} for e in snapshot['transactions'] if e.get('status')=='posted'],
                'comparison': compare(snapshot, self.get('accounts', []), list(visible.values()), self.get('mapping', {}), self.get('links',{}),
                                      {key for key,value in self.get('resolved',{}).items() if key in raw_visible and value.get('fingerprint') == fingerprint(raw_visible[key])})}

    def set_start_date(self, data):
        if has_history(self.ledger): raise ValidationError('Your existing ledger keeps its August 20, 2026 bank cutoff.')
        value = data.get('start_date')
        try:
            if not isinstance(value, str) or date.fromisoformat(value).isoformat() != value: raise ValueError()
        except ValueError:
            raise ValidationError('Choose the first date for this ledger.') from None
        if self.get('items') or self.get('transactions') or self.ledger.snapshot()['transactions']:
            raise ValidationError('Choose the ledger start date before connecting a bank or adding entries.')
        with self.db:
            self.db.execute("INSERT OR REPLACE INTO meta VALUES ('bank_import_start_date', ?)", (value,))
        self.scope_start = value
        return self.status()

    def map_accounts(self, data):
        mapping = data.get('mapping')
        if not isinstance(mapping, dict): raise ValidationError('Choose account mappings.')
        sources = {a['account_id']: a for a in self.get('accounts', [])}
        institutions = {item.get('id'):item.get('name','') for item in self.get('items', [])}
        targets = self.ledger.accounts()
        cards = set()
        for source, target in mapping.items():
            if source not in sources or not isinstance(target, str) or target not in targets:
                raise ValidationError('Choose existing bank and ledger accounts.')
            a = sources[source]
            kind = 'bank' if a.get('type') == 'depository' else 'card' if a.get('type') == 'credit' else None
            if kind != targets[target]['kind']: raise ValidationError('Map bank accounts to banks and credit cards to cards.')
            if a.get('balances', {}).get('iso_currency_code') != 'USD': raise ValidationError('Only USD accounts can be compared to this ledger.')
            if kind == 'card' and target in cards: raise ValidationError('Each ledger card can map to only one connected card.')
            if kind == 'card': cards.add(target)
        self.put('mapping', mapping)
        for source_id,target_id in mapping.items():
            source=sources[source_id]
            brand=institution_brand(institutions.get(source.get('item_id')) or source.get('official_name') or source.get('name'))
            if brand:self.db.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',('account_brand:'+target_id,brand))
        self.apply_openings_to_mapped_accounts(mapping, sources, targets)
        self.db.commit()
        self.auto_link_matches()
        self.auto_import_card_payments()
        self.auto_import_new()
        return self.status()

    def auto_import_card_payments(self):
        """Create one CP entry from a unique bank withdrawal/card credit pair."""
        if not self.writable:return
        from backend.bank_compare import cents,nearby
        from backend.bank_review import fingerprint
        transactions=self.get('transactions',{});mapping=self.get('mapping',{});links=dict(self.get('links',{}));accounts=self.ledger.accounts()
        available=[t for tid,t in transactions.items() if tid not in links and self.in_scope(t) and not t.get('pending')
                   and t.get('iso_currency_code')=='USD' and cents(t.get('amount'))]
        banks=[t for t in available if accounts.get(mapping.get(t.get('account_id')),{}).get('kind')=='bank' and cents(t.get('amount'))>0]
        cards=[t for t in available if accounts.get(mapping.get(t.get('account_id')),{}).get('kind')=='card' and cents(t.get('amount'))<0]
        used=set()
        for card_row in cards:
            card_id=mapping[card_row['account_id']];card=accounts[card_id];bank_id=card.get('default_payment_account')
            if not bank_id:continue
            raw=(' '.join((card_row.get('name') or '',card_row.get('merchant_name') or ''))).upper()
            if not any(word in raw for word in ('PAYMENT','AUTOPAY','CREDIT CARD')):continue
            amount=abs(cents(card_row['amount']))
            matches=[row for row in banks if row['transaction_id'] not in used and mapping.get(row.get('account_id'))==bank_id
                     and cents(row.get('amount'))==amount and nearby(row.get('date'),{'date':card_row.get('date')})
                     and any(word in (' '.join((row.get('name') or '',row.get('merchant_name') or ''))).upper() for word in ('PAYMENT','AUTOPAY','CREDIT CARD'))]
            if len(matches)!=1:continue
            bank_row=matches[0];code=card.get('payment_code') or 'Card payment'
            event={'kind':'card_payment','date':max(card_row['date'],bank_row['date']),'date_precision':'day','description':f'{card["name"]} payment',
                   'category':code,'account_id':card_id,'payment_bank_id':bank_id,'amount_cents':amount,'status':'posted'}
            event_id=self.ledger.save_event(event)
            group_ids=[bank_row['transaction_id'],card_row['transaction_id']]
            for row,target in ((bank_row,bank_id),(card_row,card_id)):
                links[row['transaction_id']]={'event_id':event_id,'account':target,'fingerprint':fingerprint(row),'automatic':True,'group_ids':group_ids}
            used.update(group_ids)
        if used:self.put('links',links);self.db.commit()

    def apply_openings_to_mapped_accounts(self, mapping, sources, targets):
        """Set mapped account openings from Plaid at the selected start date."""
        if has_history(self.ledger): return
        grouped = {}
        for source_id, target_id in mapping.items():
            source = sources.get(source_id)
            if source and source.get('balances', {}).get('iso_currency_code') == 'USD':
                grouped.setdefault(target_id, []).append(source)
        for target_id, linked_sources in grouped.items():
            account = targets.get(target_id)
            if not account: continue
            openings = [self.opening_from_bank(source, account['kind']) for source in linked_sources]
            if any(value is None for value in openings): continue
            self.db.execute('UPDATE accounts SET opening_cents=? WHERE id=?', (sum(openings), target_id))
            self.db.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", ('bank_opening_basis:'+target_id,
                json.dumps({'date':self.scope_start,'source_accounts':[source.get('account_id') for source in linked_sources]})))

    def settle_difference(self, data):
        if self.environment != 'production': raise ValidationError('Balance differences can only be settled against real bank data.')
        account_id = data.get('account_id')
        expected = data.get('expected_difference_cents')
        if type(expected) is not int: raise ValidationError('Reload bank balances before settling this difference.')
        row = next((item for item in self.status()['comparison']['balances'] if item['id'] == account_id), None)
        if not row or not row['complete'] or row['after_pending_cents'] is None or row['ledger_cents'] is None:
            raise ValidationError('This account needs a complete bank balance and mapping before it can be settled.')
        difference = row['difference_cents']
        if difference != expected: raise ValidationError('The balance difference changed. Sync and review it again.')
        if not difference: raise ValidationError('This account is already settled.')
        account = self.ledger.accounts().get(account_id)
        event_id = self.ledger.save_event({
            'kind':'balance_adjustment', 'amount_cents':abs(difference), 'account_id':account_id,
            'direction':'received' if difference > 0 else 'sent', 'date':data.get('date'),
            'date_precision':'day', 'status':'posted',
            'description':f"Balance adjustment · {account['name']}"
        })
        return self.status() | {'settled_event_id':event_id}

    def auto_link_matches(self):
        """Associate only unique, exact, posted bank/manual movements."""
        if not self.writable: return
        from backend.bank_compare import compare
        from backend.bank_review import fingerprint
        transactions = self.get('transactions', {})
        visible = [t for t in transactions.values() if self.in_scope(t) and not t.get('pending')]
        if not visible: return
        links = dict(self.get('links', {}))
        excluded = set(self.get('auto_link_excluded', [])) | set(self.get('resolved', {}))
        snapshot = self.ledger.snapshot()
        snapshot['transactions'] = [e for e in snapshot['transactions'] if self.in_scope(e, manual=True)]
        comparison = compare(snapshot, self.get('accounts', []), visible, self.get('mapping', {}), links)
        occupied = {(v.get('event_id'), v.get('account')) for v in links.values()}
        changed = False
        for row in comparison['transactions']:
            tid = row['transaction_id']
            if row['status'] != 'possible_match' or tid in links or tid in excluded: continue
            entry_id = row['candidates'][0]['id']
            leg = (entry_id, row['account'])
            if leg in occupied: continue
            links[tid] = {'event_id': entry_id, 'account': row['account'],
                          'fingerprint': fingerprint(transactions[tid]), 'automatic': True}
            occupied.add(leg); changed = True
        if changed:
            self.put('links', links); self.db.commit()

    def unlink(self, data):
        if not self.writable: raise ValidationError('This bank connection is preview-only.')
        tid = data.get('transaction_id')
        links = dict(self.get('links', {}))
        if tid not in links: raise ValidationError('This bank row is not linked.')
        del links[tid]
        excluded = set(self.get('auto_link_excluded', []))
        excluded.add(tid)
        self.put('links', links)
        self.put('auto_link_excluded', sorted(excluded))
        self.db.commit()
        return self.status()

    def resolve(self, data):
        if not self.writable: raise ValidationError('This bank connection is preview-only.')
        from backend.bank_review import fingerprint
        tid = data.get('transaction_id')
        transaction = self.get('transactions', {}).get(tid)
        if not transaction or not self.in_scope(transaction): raise ValidationError('Bank entry is no longer available.')
        if tid in self.get('links', {}): raise ValidationError('This bank entry is linked to the ledger. Change its link instead.')
        resolved = dict(self.get('resolved', {}))
        if data.get('resolved') is True:
            resolved[tid] = {'fingerprint': fingerprint(transaction), 'resolved_at': datetime.now(timezone.utc).isoformat()}
            excluded = set(self.get('auto_link_excluded', [])); excluded.add(tid)
            self.put('auto_link_excluded', sorted(excluded))
        elif data.get('resolved') is False:
            resolved.pop(tid, None)
        else: raise ValidationError('Choose whether to mark this entry resolved.')
        self.put('resolved', resolved); self.db.commit()
        return self.status()

    def resolve_zelle(self):
        if not self.writable:raise ValidationError('This bank connection is preview-only.')
        from backend.bank_review import fingerprint
        links=self.get('links',{});resolved=dict(self.get('resolved',{}));excluded=set(self.get('auto_link_excluded',[]));count=0
        for tid,transaction in self.get('transactions',{}).items():
            raw=(' '.join((transaction.get('name') or '',transaction.get('merchant_name') or ''))).upper()
            if tid in links or not self.in_scope(transaction) or not ('ZELLE' in raw or raw.startswith('ZEL ')):continue
            resolved[tid]={'fingerprint':fingerprint(transaction),'resolved_at':datetime.now(timezone.utc).isoformat()};excluded.add(tid);count+=1
        self.put('resolved',resolved);self.put('auto_link_excluded',sorted(excluded));self.db.commit()
        return self.status() | {'resolved_zelle_count':count}

    def resolve_internal_transfer(self, data):
        """Resolve two opposite Plaid legs inside one aggregated Basih bank."""
        if not self.writable: raise ValidationError('This bank connection is preview-only.')
        from backend.bank_compare import cents, nearby
        from backend.bank_review import fingerprint
        first_id=data.get('transaction_id');second_id=data.get('paired_transaction_id')
        transactions=self.get('transactions',{});first=transactions.get(first_id);second=transactions.get(second_id)
        if not first or not second or first_id==second_id:raise ValidationError('Choose both sides of the internal transfer.')
        mapping=self.get('mapping',{});first_target=mapping.get(first.get('account_id'));second_target=mapping.get(second.get('account_id'))
        valid=(self.in_scope(first) and self.in_scope(second) and first_target and first_target==second_target
               and first.get('account_id')!=second.get('account_id') and first.get('iso_currency_code')=='USD'
               and second.get('iso_currency_code')=='USD' and cents(first.get('amount')) is not None
               and cents(first.get('amount'))==-cents(second.get('amount')) and nearby(first.get('date'),{'date':second.get('date')}))
        if not valid:raise ValidationError('These bank records are not opposite sides of one internal transfer.')
        if first_id in self.get('links',{}) or second_id in self.get('links',{}):raise ValidationError('One side is already linked to an Activity entry.')
        resolved=dict(self.get('resolved',{}));excluded=set(self.get('auto_link_excluded',[]));group=[first_id,second_id]
        now=datetime.now(timezone.utc).isoformat()
        for transaction_id,transaction in ((first_id,first),(second_id,second)):
            resolved[transaction_id]={'fingerprint':fingerprint(transaction),'resolved_at':now,'reason':'internal_transfer','group_ids':group}
            excluded.add(transaction_id)
        self.put('resolved',resolved);self.put('auto_link_excluded',sorted(excluded));self.db.commit()
        return self.status()

    def auto_import_new(self):
        """Post newly downloaded, clearly identified merchant purchases once."""
        if not self.writable: return
        from backend.bank_compare import cents
        from backend.bank_review import review, fingerprint
        seen = set(self.get('auto_import_seen', []))
        transactions = self.get('transactions', {})
        fresh = sorted((t for tid,t in transactions.items() if tid not in seen), key=lambda t:(t.get('date',''),t.get('transaction_id','')))
        if not fresh:
            self.improve_imported_categories()
            return
        mapping = self.get('mapping', {})
        accounts = self.ledger.accounts()
        rules = self.get('merchant_rules', {})
        start = self.get('auto_import_start', self.scope_start)
        for t in fresh:
            tid = t['transaction_id']
            if not self.in_scope(t) or t.get('date','') < start or tid in self.get('links', {}) or tid in self.get('resolved', {}):
                seen.add(tid); continue
            target = mapping.get(t.get('account_id'))
            if target not in accounts: continue
            seen.add(tid)
            value = cents(t.get('amount'))
            merchant = (t.get('merchant_name') or '').strip()
            name = (t.get('name') or '').strip()
            if target not in accounts or t.get('iso_currency_code') != 'USD' or value is None or value <= 0 or not (merchant or name): continue
            raw = (merchant + ' ' + name).upper()
            if any(word in raw for word in ('TRANSFER','PAYMENT','ZELLE','ZEL ','ACH ','ATM ','REFUND','CREDIT CARD','AUTOPAY')): continue
            suggestion=purchase_suggestion(t,rules);category=suggestion['category'];description=suggestion['description']
            if category not in self.ledger.spending_categories():category=self.ledger.spending_categories()[0]
            event = {'kind':'purchase','date':t['date'],'date_precision':'day','description':description[:160],
                     'category':category,'amount_cents':value,'personal_cents':value,
                     'payer':{'type':'account','id':target},'shares':[],'status':'posted'}
            try:
                review(self, {'transaction_id':tid,'fingerprint':fingerprint(t),'event':event,'automatic':True})
            except ValidationError:
                # A possible manual match or unsupported row stays in the review inbox.
                continue
        self.put('auto_import_seen', sorted(seen));self.db.commit()
        self.improve_imported_categories()

    def improve_imported_categories(self):
        """Upgrade untouched imported Other purchases when bank data gives a fit."""
        rules=self.get('merchant_rules', {});transactions=self.get('transactions', {})
        snapshot={event['id']:event for event in self.ledger.snapshot()['transactions']}
        allowed={'payment_bank_id','kind','amount_cents','personal_cents','category','payer','shares','account_id','person_id','destination_account_id','direction','date','date_precision','description','status'}
        for tid,link in self.get('links', {}).items():
            transaction=transactions.get(tid);event=snapshot.get(link.get('event_id'))
            if not transaction or not event or event.get('kind')!='purchase' or event.get('category')!='Other':continue
            original=(transaction.get('merchant_name') or transaction.get('name') or '').strip()
            if event.get('description')!=original:continue
            suggestion=purchase_suggestion(transaction,rules)
            if suggestion['category']=='Other':continue
            if suggestion['category'] not in self.ledger.spending_categories():continue
            payload={key:value for key,value in event.items() if key in allowed}
            payload['category']=suggestion['category'];payload['description']=suggestion['description']
            self.ledger.save_event(payload,event['id'],event['revision'])

    def configure(self, data):
        if self.get('items') or self.get('link'):
            raise ValidationError(f'Disconnect {self.environment.title()} before replacing its credentials.')
        client, secret = data.get('client_id', ''), data.get('secret', '')
        if not all(isinstance(v, str) and 10 <= len(v.strip()) <= 200 for v in (client, secret)):
            raise ValidationError(f'Enter the client ID and {self.environment.title()} secret.')
        self.secret('credentials', json.dumps({'client_id': client.strip(), 'secret': secret.strip()}))
        self.put('configured', True); self.db.commit()
        return self.status()

    def start(self):
        if self.new_user_setup and self.scope_start == '0001-01-01':
            raise ValidationError('Choose “Start my ledger from” before connecting a bank.')
        existing = self.get('link')
        if existing: return {'url': existing['url']}
        result = self.call('/link/token/create', {'client_name': 'Basih', 'language': 'en',
            'country_codes': ['US'], 'products': ['transactions'], 'hosted_link': {},
            'transactions': {'days_requested': 730},
            'user': {'client_user_id': self.namespace}})
        from urllib.parse import urlparse
        url = result['hosted_link_url']; parsed = urlparse(url)
        if parsed.scheme != 'https' or parsed.hostname != 'secure.plaid.com':
            raise ValidationError('Unexpected Plaid connection URL.')
        self.secret('link', result['link_token'])
        self.put('link', {'url': url}); self.db.commit()
        return {'url': url}

    def finish(self):
        if not self.get('link'): raise ValidationError('Start a connection first.')
        result = self.call('/link/token/get', {'link_token': self.secret('link')})
        connected = False
        for session in result.get('link_sessions', []):
            for item in (session.get('results') or {}).get('item_add_results', []):
                token = item.get('public_token')
                if not token: continue
                key = 'exchanged:' + hashlib.sha256(token.encode()).hexdigest()
                if self.get(key): connected = True; continue
                exchanged = self.call('/item/public_token/exchange', {'public_token': token})
                item_id = exchanged['item_id']
                self.secret('item:' + item_id, exchanged['access_token'])
                items = self.get('items', [])
                if not any(i['id'] == item_id for i in items):
                    items.append({'id': item_id, 'name': (item.get('institution') or {}).get('name', 'Connected bank')})
                self.put('items', items); self.put(key, True); self.db.commit(); connected = True
        if not connected: return {'waiting': True}
        self.put('link', None); self.db.commit()
        return self.sync()

    def sync(self):
        accounts = {a['account_id']: a for a in self.get('accounts', [])}
        transactions = self.get('transactions', {})
        for item in self.get('items', []):
            token = self.secret('item:' + item['id'])
            cursor = self.get('cursor:' + item['id'], '')
            # Stage every page first. Any failure preserves the saved cursor and data.
            staged = dict(transactions)
            links = dict(self.get('links', {}))
            resolved = dict(self.get('resolved', {}))
            for page_number in range(1000):
                page = self.call('/transactions/sync', {'access_token': token, 'cursor': cursor, 'count': 500})
                for transaction in page.get('added', []) + page.get('modified', []):
                    staged[transaction['transaction_id']] = transaction
                    previous = transaction.get('pending_transaction_id')
                    if previous and previous in links and transaction['transaction_id'] not in links:
                        link = dict(links[previous])
                        original = transactions.get(previous, {})
                        if original.get('amount') == transaction.get('amount') and original.get('account_id') == transaction.get('account_id'):
                            from backend.bank_review import fingerprint
                            link['fingerprint'] = fingerprint(transaction)
                        links[transaction['transaction_id']] = link
                    if previous and previous in resolved and transaction['transaction_id'] not in resolved:
                        record = dict(resolved[previous])
                        original = transactions.get(previous, {})
                        if original.get('amount') == transaction.get('amount') and original.get('account_id') == transaction.get('account_id'):
                            from backend.bank_review import fingerprint
                            record['fingerprint'] = fingerprint(transaction)
                        resolved[transaction['transaction_id']] = record
                for removed in page.get('removed', []): staged.pop(removed['transaction_id'], None)
                cursor = page['next_cursor']
                if not page.get('has_more'): break
            else: raise ValidationError('Too many transaction pages. Retry sync.')
            current = self.call('/accounts/get', {'access_token': token})
            accounts = {k: a for k, a in accounts.items() if a.get('item_id') != item['id']}
            fetched = datetime.now(timezone.utc).isoformat()
            for account in current['accounts']: accounts[account['account_id']] = account | {'item_id': item['id'], 'fetched_at': fetched}
            transactions = staged
            self.put('cursor:' + item['id'], cursor)
            self.put('accounts', list(accounts.values())); self.put('transactions', transactions)
            self.put('links', links)
            self.put('resolved', resolved)
            self.put('last_sync', datetime.now(timezone.utc).isoformat()); self.db.commit()
        self.setup_new_user_accounts()
        mapping=self.get('mapping',{})
        if mapping and not has_history(self.ledger):
            sources={source.get('account_id'):source for source in self.get('accounts',[]) if source.get('account_id')}
            institutions={item.get('id'):item.get('name','') for item in self.get('items',[])}
            for source_id,target_id in mapping.items():
                source=sources.get(source_id,{})
                brand=institution_brand(institutions.get(source.get('item_id')) or source.get('official_name') or source.get('name'))
                if brand:self.db.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',('account_brand:'+target_id,brand))
            self.apply_openings_to_mapped_accounts(mapping,sources,self.ledger.accounts());self.db.commit()
        self.auto_link_matches()
        self.auto_import_card_payments()
        self.auto_import_new()
        return self.status()

    def setup_new_user_accounts(self):
        """Give an empty, shared-profile ledger accounts for its connected USD sources."""
        if not self.writable or has_history(self.ledger): return
        if not self.db.execute("SELECT 1 FROM meta WHERE key='custom_accounts'").fetchone(): return
        # A user who already created accounts chooses the Plaid mappings. Never
        # create lookalike accounts beside their existing banks or cards.
        if self.ledger.accounts(): return
        mapping = dict(self.get('mapping', {}))
        sources = self.get('accounts', [])
        for source in sources:
            source_id = source.get('account_id')
            kind = 'bank' if source.get('type') == 'depository' else 'card' if source.get('type') == 'credit' else None
            if not source_id or source_id in mapping or not kind or source.get('balances', {}).get('iso_currency_code') != 'USD': continue
            name = source.get('name') or ('Bank account' if kind == 'bank' else 'Credit card')
            mask = source.get('mask')
            opening = self.opening_from_bank(source, kind)
            account_id = self.ledger.add_account({'name': f'{name} ••{mask}' if mask else name, 'kind':kind, 'opening_cents':opening})
            mapping[source_id] = account_id
            brand=institution_brand(next((item.get('name') for item in self.get('items',[]) if item.get('id')==source.get('item_id')),None) or source.get('official_name') or source.get('name'))
            if brand:self.db.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',('account_brand:'+account_id,brand))
            if opening is not None:
                self.db.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", ('bank_opening_basis:'+account_id, json.dumps({'date':self.scope_start,'source_account':source_id})))
        if mapping != self.get('mapping', {}):
            self.put('mapping', mapping); self.db.commit()

    def opening_from_bank(self, source, kind):
        """Reconstruct the balance immediately before the selected date."""
        from backend.bank_compare import cents
        current = cents(source.get('balances', {}).get('current'))
        if current is None: return None
        rows = [t for t in self.get('transactions', {}).values()
                if t.get('account_id') == source.get('account_id') and self.in_scope(t)
                and t.get('iso_currency_code') == 'USD' and cents(t.get('amount')) is not None]
        pending = sum(cents(t['amount']) for t in rows if t.get('pending'))
        movement = sum(cents(t['amount']) for t in rows)
        # Plaid amounts are positive for money out. Cards store debt internally.
        effective_now = current - pending if kind == 'bank' else current + pending
        ledger_movement = -movement if kind == 'bank' else movement
        return effective_now - ledger_movement

    def disconnect(self):
        # Remove provider Items before forgetting tokens so failures can be retried.
        for item in list(self.get('items', [])):
            self.call('/item/remove', {'access_token': self.secret('item:' + item['id'])})
            self.storage('delete', self.namespace + ':item:' + item['id'])
            self.put('items', [i for i in self.get('items', []) if i['id'] != item['id']]); self.db.commit()
        for key in ('credentials', 'link'): self.storage('delete', self.namespace + ':' + key)
        self.db.execute(f'DELETE FROM {self.table}'); self.db.commit()
        return self.status()


def action(ledger, name, data):
    with LOCK:
        if name == 'environment':
            environment = data.get('environment')
            if environment not in ('sandbox', 'production'): raise ValidationError('Choose Sandbox or Production.')
            ledger.db.execute("INSERT OR REPLACE INTO meta VALUES ('bank_environment', ?)", (environment,)); ledger.db.commit()
        bank = BankSync(ledger)
        if name == 'environment': return bank.status()
        if data.get('environment', bank.environment) != bank.environment:
            raise ValidationError('Environment changed. Reload Bank connections before retrying.')
        if name == 'mapping': return bank.map_accounts(data)
        if name == 'start-date': return bank.set_start_date(data)
        if name == 'settle': return bank.settle_difference(data)
        if name == 'unlink': return bank.unlink(data)
        if name == 'resolve': return bank.resolve(data)
        if name == 'resolve-zelle': return bank.resolve_zelle()
        if name == 'resolve-transfer': return bank.resolve_internal_transfer(data)
        if name in ('group-preview','group-link'):
            from backend.bank_group import group
            return group(bank,data,commit=name=='group-link')
        if name == 'review':
            from backend.bank_review import review
            ledger.db.execute('BEGIN IMMEDIATE')
            try: return review(bank, data)
            except Exception:
                ledger.db.rollback(); raise
        if name == 'sync-on-open':
            if bank.writable and bank.get('items'): return bank.sync()
            return bank.status()
        if name == 'configure': return bank.configure(data)
        if name == 'start': return bank.start()
        if name == 'finish': return bank.finish()
        if name == 'sync': return bank.sync()
        if name == 'disconnect': return bank.disconnect()
        if name == 'cancel':
            bank.put('link', None); bank.db.commit(); return bank.status()
        raise ValidationError('Unknown bank action.')
