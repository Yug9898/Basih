"""Windows desktop launcher using the bundled local server and Edge app window."""
import ctypes
import os
from functools import partial
from pathlib import Path
import subprocess
import sys
import threading
import traceback
from http.server import ThreadingHTTPServer

os.environ['BASIH_EDITION'] = 'shared'


def message(text):
    ctypes.windll.user32.MessageBoxW(0, text, 'Basih', 0x10)


def find_app_browser():
    roots = [os.environ.get('PROGRAMFILES(X86)'), os.environ.get('PROGRAMFILES'), os.environ.get('LOCALAPPDATA')]
    for relative in ('Microsoft/Edge/Application/msedge.exe', 'Google/Chrome/Application/chrome.exe'):
        for root in roots:
            if root:
                candidate = Path(root) / relative
                if candidate.is_file():
                    return candidate
    return None


def run():
    from backend.server import Handler

    browser = find_app_browser()
    if browser is None:
        message('Basih needs Microsoft Edge or Google Chrome to display its app window.\n\nInstall either browser, then open the Basih Desktop shortcut again.')
        return

    data = Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'Basih'
    data.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Handler, db_path=str(data / 'basih.sqlite3')))
    server.sessions = {}; server.session_lock = threading.Lock()
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    url = f'http://127.0.0.1:{server.server_address[1]}/?desktop=1'
    try:
        profile = data / ('EdgeProfile' if browser.name.lower() == 'msedge.exe' else 'ChromeProfile')
        profile.mkdir(exist_ok=True)
        process = subprocess.Popen([str(browser), f'--app={url}', f'--user-data-dir={profile}', '--no-first-run', '--no-default-browser-check'])
        process.wait()
    finally:
        server.shutdown(); server.server_close()


if __name__ == '__main__':
    try:
        run()
    except Exception:
        data = Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'Basih'
        data.mkdir(parents=True, exist_ok=True)
        log = data / 'startup-error.txt'
        log.write_text(traceback.format_exc(), encoding='utf-8')
        message(f'Basih could not start.\n\nDetails were saved to:\n{log}')
        sys.exit(1)
