Basih for Mac — 1.0003.00.00

Unzip, then double-click Install Basih.command.
Apple Silicon Macs on macOS 26 or later receive native My Basih.
Requires an M1-or-later Mac running macOS 26 or later.

The installer verifies the new application before replacing an old Desktop copy.
Existing Basih Shared records and backups remain in Application Support.
The original Basih data folder is copied only if Basih Shared does not yet exist.

Create or sign in to an online Basih account from the People page. Existing
local People entries, ledger entries, and balances stay on this Mac during
account setup. Connection and shared-entry actions are available from People.

Restore another backup in Settings > Backups > Choose backup…
Choose your SQLite backup, enter its passcode, and confirm restoration.
A safety backup is saved first. The selected original backup remains intact.
Plaid/Tavily credentials stay in this Mac's Keychain, not in the download or backup.
macOS may request permission to access existing Keychain items again.

Touch ID in this unsigned-for-distribution build may require developer provisioning;
use your existing Basih passcode if macOS cannot enable biometric storage.
Review, statement PDF review, and Assistant use the native SwiftUI interface on macOS 26 or later.
The legacy compatibility app is no longer included or supported.
