$ErrorActionPreference = 'Stop'
$source = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $env:LOCALAPPDATA 'Programs\Basih'
$runtime = Join-Path $target 'runtime'
try {
  New-Item -ItemType Directory -Force -Path $target | Out-Null
  Copy-Item -Recurse -Force (Join-Path $source 'app') $target
  if (!(Test-Path (Join-Path $runtime 'pythonw.exe'))) {
    $archive = Join-Path $env:TEMP 'basih-python.zip'
    Invoke-WebRequest 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip' -OutFile $archive
    New-Item -ItemType Directory -Force -Path $runtime | Out-Null
    Expand-Archive -Force $archive $runtime
    Add-Content (Join-Path $runtime 'python312._pth') '..\app'
  }
  $start = Join-Path $target 'Start Basih.cmd'
  '@echo off' + "`r`n" + 'cd /d "%~dp0"' + "`r`n" + 'start "Basih" "%~dp0runtime\pythonw.exe" "%~dp0app\desktop\windows_entry.py"' | Set-Content -Encoding ASCII $start
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Basih.lnk'))
  $shortcut.TargetPath = $start
  $shortcut.WorkingDirectory = $target
  $shortcut.IconLocation = (Join-Path $env:SystemRoot 'System32\imageres.dll') + ',11'
  $shortcut.Save()
  Start-Process 'cmd.exe' -ArgumentList '/c', ('"' + $start + '"')
} catch {
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show("Basih setup could not finish.`n`n$($_.Exception.Message)",'Basih setup') | Out-Null
  exit 1
}
