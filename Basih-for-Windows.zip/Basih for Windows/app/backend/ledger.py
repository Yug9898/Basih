"""Exact, independent projections for accounts, personal spending, and people."""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
import json,os
from pathlib import Path
import sqlite3
from uuid import uuid4

CARD_PAYMENTS = {'CP1': ('CC1', 'B1'), 'CP2': ('CC2', 'B2'), 'CP3': ('CC3', 'B2')}
CATEGORIES = ('Food', 'Grocery', 'Rent', 'Tuition', 'Travel', 'Shopping', 'Other', 'Subscriptions')
DEFAULT_ACCOUNTS = (
    ('B1', 'PNC', 'bank', None), ('B2', 'Chase', 'bank', None),
    ('CC1', 'Apple Card', 'card', 'B1'),
    ('CC2', 'Chase Freedom Unlimited', 'card', 'B2'),
    ('CC3', 'Chase Sapphire Preferred', 'card', 'B2'),
)

class ValidationError(ValueError):
    pass


def cents(value, label='Amount', *, positive=False, nonnegative=False):
    # bool is an int subclass; explicitly reject it and floats/decimal strings.
    if type(value) is not int or abs(value) > 10**12 or (positive and value <= 0) or (nonnegative and value < 0):
        raise ValidationError(f'{label} must be integer cents' + (' greater than zero.' if positive else ' zero or greater.' if nonnegative else '.'))
    return value


def required_text(value, label, maximum=160):
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > maximum:
        raise ValidationError(f'{label} is required (up to {maximum} characters).')
    return value.strip()


def iso_date(value):
    try:
        if not isinstance(value, str) or date.fromisoformat(value).isoformat() != value:
            raise ValueError()
    except ValueError:
        raise ValidationError('Date must be YYYY-MM-DD.') from None
    return value


def account_purchase_delta(amount, account_kind):
    amount = cents(amount, nonnegative=True)
    if account_kind not in ('bank', 'card'):
        raise ValidationError('Unknown account kind.')
    return amount if account_kind == 'card' else -amount


def effects(event, accounts, people, categories=CATEGORIES):
    """Pure validation and effects. Positive card movement increases DEBT."""
    kind = event.get('kind')
    amount = cents(event.get('amount_cents'), nonnegative=True)
    own = cents(event.get('personal_cents', 0), 'Personal share')
    account_effects, person_effects = {}, {}
    if kind == 'balance_adjustment':
        account_id = event.get('account_id')
        if account_id not in accounts: raise ValidationError('Choose an existing account.')
        direction = event.get('direction')
        if direction not in ('received', 'sent'): raise ValidationError('Choose whether the displayed balance increases or decreases.')
        if own or event.get('shares') or event.get('person_id') or event.get('payer') or event.get('category'):
            raise ValidationError('Balance adjustments cannot change spending or person balances.')
        displayed_delta = amount if direction == 'received' else -amount
        movement = -displayed_delta if accounts[account_id]['kind'] == 'card' else displayed_delta
        return {'accounts': {account_id: movement}, 'people': {}, 'spending_cents': 0}
    if kind in ('deposit','transfer'):
        source = event.get('account_id')
        if source not in accounts or accounts[source]['kind']!='bank': raise ValidationError('Choose a bank account.')
        if own or event.get('shares') or event.get('person_id') or event.get('payer'): raise ValidationError('Deposits and transfers do not allocate spending or person effects.')
        if event.get('category') != ('Deposit' if kind=='deposit' else 'Transfer'): raise ValidationError('Choose the matching money-movement category.')
        if kind=='deposit': return {'accounts':{source:amount},'people':{},'spending_cents':0}
        dest=event.get('destination_account_id')
        if dest not in accounts or accounts[dest]['kind']!='bank' or dest==source: raise ValidationError('Choose a different destination bank.')
        return {'accounts':{source:-amount,dest:amount},'people':{},'spending_cents':0}
    if kind == 'card_payment':
        code = event.get('category')
        if 'payment_bank_id' in event or code == 'Card payment':
            card, bank = event.get('account_id'), event.get('payment_bank_id')
            if card not in accounts or accounts[card]['kind']!='card' or bank not in accounts or accounts[bank]['kind']!='bank':
                raise ValidationError('Choose a card and link its payment bank first.')
            if code != 'Card payment' and accounts[card].get('payment_code') != code:raise ValidationError('Payment code must match its card.')
        elif code in CARD_PAYMENTS:
            card, bank = CARD_PAYMENTS[code]
        else: raise ValidationError('Choose a card payment category.')
        if card not in accounts or bank not in accounts: raise ValidationError('Required card/bank account missing.')
        if own or event.get('shares') or event.get('person_id'): raise ValidationError('Card payments do not create spending or person effects.')
        if event.get('account_id', card) != card: raise ValidationError('Payment code must match its card.')
        return {'accounts': {bank: -amount, card: -amount}, 'people': {}, 'spending_cents': 0}
    if kind == 'purchase':
        if own < 0 or own > amount:
            raise ValidationError('Personal share must be between zero and the total.')
        if event.get('category') not in categories:
            raise ValidationError('Choose a spending category.')
        payer = event.get('payer', {})
        if not isinstance(payer, dict):
            raise ValidationError('Choose a payer.')
        shares = event.get('shares', [])
        if not isinstance(shares, list):
            raise ValidationError('Shares must be a list.')
        shared_total = 0
        for share in shares:
            if not isinstance(share, dict) or share.get('person_id') not in people:
                raise ValidationError('Each share must identify an existing person.')
            person = share['person_id']
            if person in person_effects:
                raise ValidationError('Each person may appear only once in a split.')
            share_amount = cents(share.get('amount_cents'), 'Person share', positive=True)
            shared_total += share_amount
            person_effects[person] = share_amount
        if own + shared_total != amount:
            raise ValidationError('Your share and all person shares must equal the purchase total.')
        if payer.get('type') == 'account' and payer.get('id') in accounts:
            account = accounts[payer['id']]
            account_effects[account['id']] = account_purchase_delta(amount, account['kind'])
        elif payer.get('type') == 'person' and payer.get('id') in people:
            # Only the user's share is owed to the payer. Do not model other people's debts.
            if shares or own != amount:
                raise ValidationError('For a person-paid purchase, enter only the amount paid for your share.')
            person_effects = {payer['id']: -own}
        else:
            raise ValidationError('Choose an existing account or person as payer.')
        return {'accounts': account_effects, 'people': person_effects, 'spending_cents': own}
    if kind == 'refund':
        account_id = event.get('account_id')
        if account_id not in accounts: raise ValidationError('Choose the account that received the refund.')
        if event.get('category') not in categories: raise ValidationError('Choose the refunded spending category.')
        if own < 0 or own > amount: raise ValidationError('Your refunded share must be between zero and the refund total.')
        if event.get('shares') or event.get('person_id') or event.get('payer') or event.get('direction'):
            raise ValidationError('Refunds cannot change person balances directly.')
        movement = amount if accounts[account_id]['kind'] == 'bank' else -amount
        return {'accounts': {account_id: movement}, 'people': {}, 'spending_cents': -own}
    if kind in ('person_debt','borrowing'):
        person = event.get('person_id')
        if person not in people: raise ValidationError('Choose an existing person.')
        if own or event.get('shares') or event.get('category') or event.get('payer') or event.get('direction'):
            raise ValidationError('Debt entries do not allocate personal spending or purchase shares.')
        if kind == 'borrowing':
            bank = event.get('account_id')
            if bank not in accounts or accounts[bank]['kind'] != 'bank': raise ValidationError('Choose the bank that received the borrowed money.')
            account_effects = {bank:amount}
        elif event.get('account_id'): raise ValidationError('Debt-only entries do not move money between accounts.')
        return {'accounts':account_effects,'people':{person:-amount},'spending_cents':0}
    if kind == 'repayment':
        account_id, person_id = event.get('account_id'), event.get('person_id')
        if account_id not in accounts or accounts[account_id]['kind'] != 'bank':
            raise ValidationError('Repayments need an existing bank account.')
        if person_id not in people:
            raise ValidationError('Choose an existing person.')
        direction = event.get('direction')
        if direction not in ('received', 'sent'):
            raise ValidationError('Choose received or sent repayment.')
        if own != 0 or event.get('shares') or event.get('category'):
            raise ValidationError('Repayments cannot create personal spending or purchase splits.')
        sign = 1 if direction == 'received' else -1
        return {'accounts': {account_id: sign * amount}, 'people': {person_id: -sign * amount}, 'spending_cents': 0}
    raise ValidationError('Supported events are purchases, repayments and CP card payments.')


class Ledger:
    def __init__(self, path):
        self.path = str(path)
        if self.path != ':memory:':
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA foreign_keys = ON')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS accounts (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('bank','card')),
                opening_cents INTEGER, default_payment_account TEXT REFERENCES accounts(id)
            );
            CREATE TABLE IF NOT EXISTS people (id TEXT PRIMARY KEY, name TEXT NOT NULL, opening_cents INTEGER);
            CREATE TABLE IF NOT EXISTS person_notes (person_id TEXT PRIMARY KEY REFERENCES people(id), text TEXT NOT NULL, revision INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS events (
                seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL,
                entered_at TEXT NOT NULL, revision INTEGER NOT NULL, payload TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS revisions (
                event_id TEXT NOT NULL REFERENCES events(id), revision INTEGER NOT NULL,
                recorded_at TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(event_id,revision)
            );
            CREATE TABLE IF NOT EXISTS categories (
                name TEXT PRIMARY KEY COLLATE NOCASE, position INTEGER NOT NULL
            );
        ''')
        with self.db:
            if not self.db.execute('SELECT 1 FROM categories').fetchone():
                self.db.executemany('INSERT INTO categories(name,position) VALUES(?,?)',((name,index) for index,name in enumerate(CATEGORIES)))
            if os.environ.get('BASIH_EDITION') in ('test','shared') and not self.db.execute("SELECT 1 FROM meta WHERE key='custom_accounts'").fetchone():
                existing=list(self.db.execute('SELECT * FROM accounts ORDER BY rowid'))
                pristine=[(r['id'],r['name'],r['kind'],r['default_payment_account']) for r in existing]==list(DEFAULT_ACCOUNTS) and all(r['opening_cents'] is None for r in existing)
                history=self.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='source_history'").fetchone()
                if pristine and not history and not self.db.execute('SELECT 1 FROM events').fetchone():
                    self.db.execute("DELETE FROM accounts WHERE kind='card'")
                    self.db.execute("DELETE FROM accounts WHERE kind='bank'")
                self.db.execute("INSERT INTO meta VALUES('custom_accounts','1')")
            custom=self.db.execute("SELECT 1 FROM meta WHERE key='custom_accounts'").fetchone()
            history_table=self.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='source_history'").fetchone()
            if custom and not history_table:
                # Shared/Plaid-first profiles treat a newly added person as all
                # square unless the user entered a non-zero opening balance.
                self.db.execute('UPDATE people SET opening_cents=0 WHERE opening_cents IS NULL')
            for account in (() if custom else DEFAULT_ACCOUNTS):
                if self.db.execute('SELECT 1 FROM meta WHERE key IN (?,?)', ('deleted_card:'+account[0],'deleted_account:'+account[0])).fetchone():
                    continue
                self.db.execute('INSERT OR IGNORE INTO accounts(id,name,kind,default_payment_account) VALUES(?,?,?,?)', account)

    def close(self):
        self.db.close()

    def accounts(self):
        codes={r['key'][13:]:r['value'] for r in self.db.execute("SELECT key,value FROM meta WHERE key LIKE 'payment_code:%'")}
        brands={r['key'][14:]:r['value'] for r in self.db.execute("SELECT key,value FROM meta WHERE key LIKE 'account_brand:%'")}
        return {r['id']: dict(r) | {'brand':brands.get(r['id']),'payment_code':codes.get(r['id'], next((code for code,(card,bank) in CARD_PAYMENTS.items() if card==r['id']),None))} for r in self.db.execute('SELECT * FROM accounts ORDER BY rowid')}

    def people(self):
        return {r['id']: dict(r) for r in self.db.execute("SELECT p.*, COALESCE(n.text,'') AS note, COALESCE(n.revision,0) AS note_revision FROM people p LEFT JOIN person_notes n ON n.person_id=p.id ORDER BY p.rowid")}

    def spending_categories(self):
        return [r['name'] for r in self.db.execute('SELECT name FROM categories ORDER BY position,name COLLATE NOCASE')]

    def save_person_note(self, person_id, text, expected_revision):
        if person_id not in self.people(): raise ValidationError('Person not found.')
        if not isinstance(text,str) or len(text)>10000: raise ValidationError('Note must be text up to 10,000 characters.')
        if type(expected_revision) is not int: raise ValidationError('Note revision is required.')
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO person_notes VALUES(?, ?, 0)',(person_id,''))
            changed=self.db.execute('UPDATE person_notes SET text=?,revision=revision+1 WHERE person_id=? AND revision=?',(text,person_id,expected_revision))
            if changed.rowcount!=1: raise ValidationError('Note changed; reload before saving.')
        return expected_revision+1

    def add_person(self, data):
        name = required_text(data.get('name'), 'Name', 80)
        opening = data.get('opening_cents')
        if opening is not None: cents(opening, 'Opening person balance')
        person_id = str(uuid4())
        with self.db:
            self.db.execute('INSERT INTO people VALUES(?,?,?)', (person_id, name, opening))
        return person_id

    def add_account(self, data):
        name = required_text(data.get('name'), 'Name', 80)
        kind = data.get('kind')
        if kind not in ('bank', 'card'): raise ValidationError('Account kind must be bank or card.')
        opening = data.get('opening_cents')
        if opening is not None: cents(opening, 'Opening balance')
        default = data.get('default_payment_account')
        if default is not None and (kind != 'card' or default not in self.accounts() or self.accounts()[default]['kind'] != 'bank'):
            raise ValidationError('Default card payment source must be a bank account.')
        account_id = str(uuid4())
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            custom=self.db.execute("SELECT 1 FROM meta WHERE key='custom_accounts'").fetchone()
            if custom:
                prefix='B' if kind=='bank' else 'CC'
                prior=self.db.execute('SELECT value FROM meta WHERE key=?',('account_counter:'+kind,)).fetchone()
                used=[int(r[0][len(prefix):]) for r in self.db.execute('SELECT id FROM accounts') if r[0].startswith(prefix) and r[0][len(prefix):].isdigit()]
                deleted=[r[0].split(':',1)[1] for r in self.db.execute("SELECT key FROM meta WHERE key LIKE 'deleted_account:%' OR key LIKE 'deleted_card:%'")]
                used += [int(value[len(prefix):]) for value in deleted if value.startswith(prefix) and value[len(prefix):].isdigit()]
                if kind=='card':used += [int(r[0][2:]) for r in self.db.execute("SELECT value FROM meta WHERE key LIKE 'payment_code:%'")]
                number=max([int(prior[0]) if prior else 0]+used)+1
                account_id=prefix+str(number)
                self.db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('account_counter:'+kind,str(number)))
            self.db.execute('INSERT INTO accounts VALUES(?,?,?,?,?)', (account_id, name, kind, opening, default))
            if kind=='card':
                used=[int(r[0][2:]) for r in self.db.execute("SELECT value FROM meta WHERE key LIKE 'payment_code:%'")]
                code='CP'+str(number if custom else max([3]+used)+1)
                self.db.execute('INSERT INTO meta VALUES(?,?)',('payment_code:'+account_id,code))
        return account_id

    def validate(self, data):
        if not isinstance(data, dict): raise ValidationError('Event must be an object.')
        allowed = {'payment_bank_id', 'kind', 'amount_cents', 'personal_cents', 'category', 'payer', 'shares', 'account_id',
                   'person_id', 'destination_account_id', 'direction', 'date', 'date_precision', 'description', 'status'}
        if set(data) - allowed: raise ValidationError('Event contains unsupported fields.')
        event = dict(data)
        if event.get('kind')=='card_payment' and 'payment_bank_id' not in event:
            card=next((a for a in self.accounts().values() if a['payment_code']==event.get('category')),None)
            if card:
                event.setdefault('account_id',card['id'])
                event['payment_bank_id']=card['default_payment_account']
            elif event.get('category')=='Card payment':
                event['payment_bank_id']=self.accounts().get(event.get('account_id'),{}).get('default_payment_account')
        event['date'] = iso_date(event.get('date'))
        precision = event.setdefault('date_precision', 'day')
        if precision not in ('day', 'week'): raise ValidationError('Date precision must be day or week.')
        if precision == 'week' and date.fromisoformat(event['date']).weekday() != 6:
            raise ValidationError('A weekly record needs its Sunday start date, not an invented transaction day.')
        event['description'] = required_text(event.get('description'), 'Description')
        if event.setdefault('status', 'posted') not in ('pending', 'posted'):
            raise ValidationError('Status must be pending or posted.')
        movement = effects(event, self.accounts(), self.people(), self.spending_categories())
        cutover = self.db.execute("SELECT value FROM meta WHERE key='notes_cutover'").fetchone()
        if cutover and event['date'] < cutover['value'] and movement['people']:
            raise ValidationError('This person balance is already included in the Notes cutover. Use the cutover date or later.')
        return event

    def save_event(self, data, event_id=None, expected_revision=None):
        if event_id and isinstance(data,dict) and data.get('kind')=='card_payment' and 'payment_bank_id' not in data:
            previous=self.db.execute('SELECT payload FROM events WHERE id=?',(event_id,)).fetchone()
            if previous:
                old=json.loads(previous['payload'])
                if old.get('kind')=='card_payment' and old.get('category')==data.get('category'):
                    bank=old.get('payment_bank_id') or CARD_PAYMENTS.get(old.get('category'),(None,None))[1]
                    if bank:data=data | {'payment_bank_id':bank}
        event = self.validate(data)
        now = datetime.now(timezone.utc).isoformat(timespec='microseconds')
        payload = json.dumps(event, sort_keys=True)
        with self.db:
            if event_id:
                existing = self.db.execute('SELECT revision FROM events WHERE id=?', (event_id,)).fetchone()
                if not existing: raise ValidationError('Event not found.')
                if expected_revision != existing['revision']:
                    raise ValidationError('This event changed. Reload before correcting it.')
                revision = existing['revision'] + 1
                updated = self.db.execute('UPDATE events SET payload=?, revision=? WHERE id=? AND revision=?', (payload, revision, event_id, expected_revision))
                if updated.rowcount != 1:
                    raise ValidationError('This event changed. Reload before correcting it.')
            else:
                event_id, revision = str(uuid4()), 1
                self.db.execute('INSERT INTO events(id,entered_at,revision,payload) VALUES(?,?,?,?)', (event_id, now, revision, payload))
            self.db.execute('INSERT INTO revisions VALUES(?,?,?,?)', (event_id, revision, now, payload))
        return event_id

    def delete_event(self,event_id,expected_revision):
        existing=self.db.execute('SELECT revision,payload FROM events WHERE id=?',(event_id,)).fetchone()
        if not existing:raise ValidationError('Entry not found.')
        if type(expected_revision) is not int or existing['revision']!=expected_revision:raise ValidationError('Entry changed; reload before deleting.')
        event=json.loads(existing['payload'])
        if event.get('status')=='voided':raise ValidationError('Entry is already deleted.')
        event['status']='voided';revision=expected_revision+1
        now=datetime.now(timezone.utc).isoformat(timespec='microseconds');payload=json.dumps(event,sort_keys=True)
        with self.db:
            changed=self.db.execute('UPDATE events SET payload=?,revision=? WHERE id=? AND revision=?',(payload,revision,event_id,expected_revision))
            if changed.rowcount!=1:raise ValidationError('Entry changed; reload before deleting.')
            self.db.execute('INSERT INTO revisions VALUES(?,?,?,?)',(event_id,revision,now,payload))
        return revision

    def restore_event(self,event_id,expected_revision):
        existing=self.db.execute('SELECT revision,payload FROM events WHERE id=?',(event_id,)).fetchone()
        if not existing or type(expected_revision) is not int or existing['revision']!=expected_revision:raise ValidationError('Deleted entry changed; reload before restoring.')
        if json.loads(existing['payload']).get('status')!='voided':raise ValidationError('Entry is not deleted.')
        previous=self.db.execute('SELECT payload FROM revisions WHERE event_id=? AND revision<? ORDER BY revision DESC',(event_id,expected_revision)).fetchall()
        event=next((json.loads(r[0]) for r in previous if json.loads(r[0]).get('status')!='voided'),None)
        if event is None:raise ValidationError('Original entry unavailable.')
        return self.save_event(event,event_id,expected_revision)

    def history(self, event_id):
        return [dict(r) | {'payload': json.loads(r['payload'])} for r in self.db.execute(
            'SELECT * FROM revisions WHERE event_id=? ORDER BY revision', (event_id,))]

    def snapshot(self, filters=None):
        accounts, people = self.accounts(), self.people()
        posted_a = {k: 0 for k in accounts}; projected_a = posted_a.copy()
        posted_p = {k: 0 for k in people}; projected_p = posted_p.copy()
        rows = []
        manual_pnc = {}; manual_pnc_revisions = {}
        if self.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='manual_pnc'").fetchone():
            manual_pnc = {r['source_row']: r['balance_cents'] for r in self.db.execute('SELECT * FROM manual_pnc ORDER BY revision')}
        manual_pnc_revisions = {r['source_row']: r['revision'] for r in self.db.execute('SELECT * FROM manual_pnc ORDER BY revision')} if manual_pnc else {}
        checkpoint_offset = 0
        early_b1_movement = 0
        records = []
        if self.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='imported_events'").fetchone():
            records.extend(dict(r) | {'revision': 1, 'imported': True} for r in self.db.execute('SELECT * FROM imported_events ORDER BY seq'))
        confirmation_row = self.db.execute("SELECT value FROM meta WHERE key='pnc_confirmed_checkpoint'").fetchone()
        confirmation = json.loads(confirmation_row[0]) if confirmation_row else None
        confirmation_offset = 0
        last_import_seq = max((r['seq'] for r in records),default=None)
        records.extend(dict(r) for r in self.db.execute("SELECT * FROM events ORDER BY json_extract(payload,'$.date'),seq"))
        for record in records:
            event = json.loads(record['payload'])
            # Older imports omitted money-movement categories. Restore display/filter
            # metadata in memory; keep the stored financial effects unchanged.
            if record.get('imported') and not event.get('category'):
                original_kind = event.get('original_kind')
                if original_kind == 'deposit_purpose_unconfirmed':
                    event['category'] = 'Deposit'
                elif original_kind == 'transfer':
                    event['category'] = 'Transfer'
                elif original_kind == 'card_payment':
                    event['category'] = next((code for code, (card, bank) in CARD_PAYMENTS.items()
                                              if card in event['effects']['accounts']), None)
            if event.get('status')=='voided':continue
            impact = event['effects'] if record.get('imported') else effects(event, accounts, people, self.spending_categories())
            if event.get('kind')=='repayment' and not event.get('category'):event=event|{'category':'Debited'}
            for key, value in impact['accounts'].items():
                projected_a[key] += value
                if event['status'] == 'posted': posted_a[key] += value
            for key, value in impact['people'].items():
                projected_p[key] += value
                if event['status'] == 'posted': posted_p[key] += value
            if record.get('imported') and event.get('source_row', 0) <= 9:
                early_b1_movement = posted_a.get('B1', 0)
            if manual_pnc and 9 in manual_pnc:
                checkpoint_offset = manual_pnc[9] - ((accounts['B1']['opening_cents'] or 0) + early_b1_movement)
            # Null baseline is distinct from a known zero. Always expose movements too.
            running = {k: (a['opening_cents'] + posted_a[k] if a['opening_cents'] is not None else None) for k, a in accounts.items()}
            projected_running = {k: (a['opening_cents'] + projected_a[k] if a['opening_cents'] is not None else None) for k, a in accounts.items()}
            if manual_pnc:
                source_row = event.get('source_row')
                if source_row in manual_pnc:
                    running['B1'] = manual_pnc[source_row]
                    projected_running['B1'] = manual_pnc[source_row]
                elif (record.get('imported') and source_row > 9) or not record.get('imported'):
                    if running['B1'] is not None: running['B1'] += checkpoint_offset
                    if projected_running['B1'] is not None: projected_running['B1'] += checkpoint_offset
            if confirmation and ((record.get('imported') and record['seq']==last_import_seq) or not record.get('imported')):
                if record.get('imported'):
                    confirmation_offset = confirmation['balance_cents'] - running['B1']
                    event = event | {'calculation_notes':event.get('calculation_notes',[])+[f"PNC uses the user-confirmed {confirmation['date']} checkpoint of {confirmation['balance_cents'] / 100:.2f}. Reconstruction difference: {confirmation_offset / 100:+.2f}; separate from this transaction."]}
                if running['B1'] is not None: running['B1'] += confirmation_offset
                if projected_running['B1'] is not None: projected_running['B1'] += confirmation_offset
            rows.append(event | {'id': record['id'], 'seq': record['seq'], 'entered_at': record['entered_at'].replace(' ', 'T')+'Z' if record.get('imported') else record['entered_at'],
                'revision': record['revision'], 'effects': impact, 'running_balances': running,
                'projected_running_balances': projected_running, 'running_movements': posted_a.copy(),
                'projected_running_movements': projected_a.copy()})
        filters = filters or {}
        def matches(row):
            return (not filters.get('account') or filters['account'] in row['effects']['accounts']) and (
                not filters.get('person') or filters['person'] in row['effects']['people']) and (
                not filters.get('category') or row.get('category') == filters['category']) and (
                not filters.get('from') or (date.fromisoformat(row['date']) + timedelta(days=6 if row.get('date_precision') == 'week' else 0)).isoformat() >= filters['from']) and (
                not filters.get('to') or row['date'] <= filters['to'])
        selected = [r for r in rows if matches(r)]
        spending_categories=self.spending_categories()
        category_totals = {c: sum(r['effects']['spending_cents'] or 0 for r in selected if r.get('category') == c and r['status'] == 'posted') for c in spending_categories}
        def summary(item, posted, projected):
            opening = item['opening_cents']
            offset = checkpoint_offset + confirmation_offset if item['id']=='B1' else 0
            cc3_basis=self.db.execute("SELECT value FROM meta WHERE key='cc3_opening_basis'").fetchone() if item['id']=='CC3' else None
            bank_basis=self.db.execute("SELECT value FROM meta WHERE key=?",('bank_opening_basis:'+item['id'],)).fetchone()
            bank_basis=json.loads(bank_basis['value']) if bank_basis else None
            return item | {'opening_basis': cc3_basis['value'] if cc3_basis else None,
                           'opening_date':bank_basis.get('date') if bank_basis else None,
                           'posted_movement_cents': posted, 'projected_movement_cents': projected,
                           'manual_checkpoint_offset_cents': checkpoint_offset if item['id']=='B1' else 0,
                           'confirmed_checkpoint': confirmation if item['id']=='B1' else None,
                           'confirmation_difference_cents': confirmation_offset if item['id']=='B1' else 0, 'posted_balance_cents': opening + posted + offset if opening is not None else None,
                           'projected_balance_cents': opening + projected + offset if opening is not None else None}
        return {'demo': self.db.execute("SELECT value FROM meta WHERE key='demo'").fetchone() is not None,
            'accounts': [summary(a, posted_a[k], projected_a[k]) for k, a in accounts.items()],
            'people': [summary(p, posted_p[k], projected_p[k]) for k, p in people.items()],
            'transactions': selected, 'categories': spending_categories + [a['payment_code'] for a in accounts.values() if a['payment_code']] + ['Deposit','Transfer','Debited'], 'category_totals': category_totals,
            'profile_name': self.db.execute("SELECT value FROM meta WHERE key='profile_name'").fetchone()[0] if self.db.execute("SELECT value FROM meta WHERE key='profile_name'").fetchone() else None,
            'hidden_categories':[c for c in spending_categories if self.db.execute("SELECT 1 FROM meta WHERE key=? AND value='1'",('hidden_category:'+c,)).fetchone()],
            'personal_spending_cents': sum(category_totals.values()),
            'unknown_personal_shares': sum(r['effects']['spending_cents'] is None for r in selected),
            'manual_pnc': manual_pnc, 'manual_pnc_revisions': manual_pnc_revisions,
            'notes_cutover': self.db.execute("SELECT value FROM meta WHERE key='notes_cutover'").fetchone()['value'] if self.db.execute("SELECT value FROM meta WHERE key='notes_cutover'").fetchone() else None,
            'pending_personal_spending_cents': sum(r['effects']['spending_cents'] for r in selected if r['status'] == 'pending'),
            'total_events': len(rows)}

    def seed_demo(self):
        if self.db.execute("SELECT 1 FROM meta WHERE key='demo'").fetchone(): return
        if self.db.execute('SELECT 1 FROM events').fetchone() or self.people():
            raise ValidationError('Demo seed requires an empty database. Use a separate demo database.')
        with self.db:
            self.db.execute("INSERT INTO meta VALUES('demo','synthetic')")
            for account, opening in [('B1', 240000), ('B2', 80000), ('CC1', 0), ('CC2', 0), ('CC3', 0)]:
                self.db.execute('UPDATE accounts SET opening_cents=? WHERE id=?', (opening, account))
            alex = self.add_person({'name': 'Alex · demo', 'opening_cents': 2000})
            sam = self.add_person({'name': 'Sam · demo', 'opening_cents': 0})
            today = date.today()
            def purchase(days, description, amount, personal, account, category, shares=None):
                return {'kind':'purchase','date':(today-timedelta(days=days)).isoformat(), 'description':description,
                    'amount_cents':amount, 'personal_cents':personal, 'payer':{'type':'account','id':account},
                    'category':category, 'shares':shares or [], 'status':'posted'}
            self.save_event(purchase(4, 'Dinner with Alex', 4000, 2000, 'CC1', 'Food', [{'person_id':alex,'amount_cents':2000}]))
            self.save_event(purchase(3, 'The weekly grocery run', 5675, 5675, 'B2', 'Grocery'))
            self.save_event({'kind':'purchase','date':(today-timedelta(days=2)).isoformat(),'description':'Sam picked up my coffee',
                'amount_cents':650,'personal_cents':650,'category':'Food','payer':{'type':'person','id':sam},'shares':[],'status':'posted'})
            self.save_event({'kind':'repayment','date':(today-timedelta(days=1)).isoformat(),'description':'Alex sent a partial repayment',
                'amount_cents':3000,'account_id':'B1','person_id':alex,'direction':'received','status':'posted'})
            pending = purchase(0, 'Bookshop · pending', 2400, 2400, 'CC3', 'Shopping'); pending['status'] = 'pending'
            self.save_event(pending)
