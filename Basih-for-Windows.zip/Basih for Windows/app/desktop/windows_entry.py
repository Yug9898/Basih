"""Windows desktop launcher using the bundled local server and Edge app window."""
import ctypes
import os
from functools import partial
from pathlib import Path
import subprocess
import sys
import threading
import traceback
import webbrowser
from http.server import ThreadingHTTPServer

os.environ['BASIH_EDITION'] = 'shared'


def message(text):
    ctypes.windll.user32.MessageBoxW(0, text, 'Basih', 0x10)


def run():
    from backend.server import Handler

    data = Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'Basih'
    data.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Handler, db_path=str(data / 'basih.sqlite3')))
    server.sessions = {}; server.session_lock = threading.Lock()
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    url = f'http://127.0.0.1:{server.server_address[1]}'
    roots = [os.environ.get('PROGRAMFILES(X86)'), os.environ.get('PROGRAMFILES'), os.environ.get('LOCALAPPDATA')]
    edge_candidates = [Path(root) / 'Microsoft/Edge/Application/msedge.exe' for root in roots if root]
    edge = next((path for path in edge_candidates if path.is_file()), None)
    try:
        if edge:
            profile = data / 'EdgeProfile'; profile.mkdir(exist_ok=True)
            process = subprocess.Popen([str(edge), f'--app={url}', f'--user-data-dir={profile}', '--no-first-run'])
            process.wait()
        else:
            # Keep this process and its local server alive when the default browser
            # is used. pythonw has no stdin, so waiting for input closes instantly.
            webbrowser.open(url)
            threading.Event().wait()
    finally:
        server.shutdown(); server.server_close()


if __name__ == '__main__':
    try:
        run()
    except Exception:
        data = Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'Basih'
        data.mkdir(parents=True, exist_ok=True)
        log = data / 'startup-error.txt'
        log.write_text(traceback.format_exc(), encoding='utf-8')
        message(f'Basih could not start.\n\nDetails were saved to:\n{log}')
        sys.exit(1)
