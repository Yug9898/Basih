"""Bank review starts with the user's current ledger period."""
from datetime import date,timedelta

START_DATE='2026-08-20'

def in_scope(entry, manual=False, start_date=START_DATE):
    try:
        end=date.fromisoformat(entry.get('date',''))
        if manual and entry.get('date_precision')=='week':end+=timedelta(days=6)
        return end>=date.fromisoformat(start_date)
    except (TypeError,ValueError):return False
