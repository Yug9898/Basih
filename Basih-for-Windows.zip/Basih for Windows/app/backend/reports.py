"""Personal-share period summaries. Averages never become stored monetary postings."""
from datetime import date,timedelta
from decimal import Decimal,ROUND_HALF_UP

def summary(ledger, through=None, selected_week=None, monthly_basis='tracking', tracking_year=None):
    end=date.fromisoformat(through) if through else date.today()
    preference=ledger.db.execute("SELECT value FROM meta WHERE key='report_year_basis'").fetchone()
    year_basis=preference[0] if preference else 'tracking'
    start_month,start_day=(4,1) if year_basis=='fiscal' else (8,21)
    current_year=end.year if end>=date(end.year,start_month,start_day) else end.year-1
    year=int(tracking_year) if tracking_year is not None else current_year
    if not 1900<=year<=current_year:raise ValueError('Choose a current or previous tracking year.')
    year_start=date(year,start_month,start_day)
    year_end=date(year+1,start_month,start_day)-timedelta(days=1)
    end=min(end,year_end)
    current_sunday=end-timedelta(days=(end.weekday()+1)%7)
    week=date.fromisoformat(selected_week) if selected_week else current_sunday
    week-=timedelta(days=(week.weekday()+1)%7)
    if week+timedelta(days=6)<year_start or week>end:week=current_sunday
    state=ledger.snapshot(); rows=state['transactions']
    def interval(r):
        start=date.fromisoformat(r['date']);return start,start+timedelta(days=6 if r.get('date_precision')=='week' else 0)
    def overlaps(r,start,finish):
        first,last=interval(r);return first<=finish and last>=start
    # Weekly history has no individual purchase dates. Assign a whole week to
    # the tracking year containing its final day, avoiding duplicate year totals.
    covered=[r for r in rows if r['status']=='posted' and overlaps(r,year_start,end)
             and year_start<=interval(r)[1]<=year_end]
    weeks=max(1,((current_sunday-(year_start+timedelta(days=(6-year_start.weekday())%7))).days//7)+1)
    if monthly_basis=='calendar':
        months=(end.year-year_start.year)*12+end.month-year_start.month+1
        month_start=date(end.year,end.month,1)
    else:
        months=(end.year-year_start.year)*12+end.month-year_start.month+(1 if end.day>=21 else 0)+(1 if year_start.day<21 else 0)
        months=max(1,months)
        month_start=date(end.year,end.month,21) if end.day>=21 else date(end.year-1 if end.month==1 else end.year,12 if end.month==1 else end.month-1,21)
    def total(category,entries):return sum(r['effects']['spending_cents'] or 0 for r in entries if r.get('category')==category)
    def average(value,count):return int((Decimal(value)/count).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
    groups=[]
    for period,categories,denominator in [('Weekly',['Food','Grocery'],weeks),('Monthly',['Rent'],months),('Yearly',['Tuition','Travel','Other','Shopping'],1),('Tracking year',['Subscriptions'],1)]:
        entries=[]
        for category in categories:
            amount=total(category,covered)
            selection=[r for r in covered if overlaps(r,week,min(end,week+timedelta(days=6)))] if period=='Weekly' else [r for r in covered if overlaps(r,month_start,end)] if period=='Monthly' else covered
            entries.append({'category':category,'average_cents':average(amount,denominator),'total_cents':amount,'selected_cents':total(category,selection),
                            'unknown_shares':sum(r.get('category')==category and r['effects']['spending_cents'] is None for r in covered)})
        groups.append({'period':period,'count':denominator,'rows':entries})
    years={current_year,year}
    for r in rows:
        first,last=interval(r)
        for day in (first,last):years.add(day.year if day>=date(day.year,start_month,start_day) else day.year-1)
    return {'year_basis':year_basis,'tracking_year':year,'available_years':sorted((y for y in years if 1900<=y<=current_year),reverse=True),'year_end':year_end.isoformat(),'from':year_start.isoformat(),'through':end.isoformat(),'selected_week':week.isoformat(),'monthly_basis':monthly_basis,'month_from':max(month_start,year_start).isoformat(),
            'groups':groups,'total_cents':sum(total(c,covered) for c in ['Food','Grocery','Rent','Tuition','Travel','Other','Shopping','Subscriptions']),
            'incomplete_current_period':end<year_end,'week_uncertainty':'Weekly entries belong to the reporting year containing their Saturday. Exact-day entries use their date; monthly boundaries may include a whole week.',
            'coverage':'Supplied current-year history and app entries; missing historical coverage is not assumed complete.'}
